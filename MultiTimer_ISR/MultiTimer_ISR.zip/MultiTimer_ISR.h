//###############################    MultiTimer ISR    ############################## //
//
//   Author:  Vinicius Calil
//   Date:   december/2020
//
//   Objective: Share one single microcontroller's timer among many independent
//              interrupt handling function. I.e., transform a single hardware
//              timer in many software timers.
//   Hardware: Arduino UNO
//   Compiler: AVR GCC
//
//
//   Description:
//
//    Although Timer/Counter1 supports four different functions as Interrupt Service
//    Routine-ISR (TIMER1 CAPT, TIMER1 COMPA, TIMER1 COMPB and TIMER1 OVF) some times
//    an application may require only simple operation like "TIMER1 COMPA" ISR, but
//    for many completely independent functions.
//    This header file allows multiple functions (hereby called Pseudo Interrupt
//    Handler-PIH) to be scheduled, each one with its own independent time interval
//    requirements, in Timer/Counter1 "TIMER1 COMPA" ISR. In this way, Timer/Counter1
//    hardware is shared among multiple PIH and behaves like the microcontroller has
//    a lot of timers available.
//
//    The programmer may INCLUDE many functions "Pseudo Interrupt Handler-PIH" to the
//    Timer/Counter1's schedule control by passing, at least, a function pointer
//    (pointed to the desired PIH) and a time interval between consecutive interrupt
//    calls to this PIH. The 'struct' created when a PIH is included in Timer/Counter1's
//    schedule control is referred as a "SCHEDULE".
//    Any SCHEDULE may ALSO be supplied with the following information: number of times
//    that its PIH must be called, the ID of another SCHEDULE used to synchronize the new
//    one that is being included, and a delay/off-set interval between the interrupt call of
//    the new included PIH and the other PIH used to synchronize the new one.
//
//    This library sets Timer/Counter1 in Clear Timer on Compare Match (CTC) Mode with
//    TOP set to OCR1A. The interrupt vector "TIMER1_COMPA_vect" is called every time
//    TCNT1 is equal to OCR1A.
//    This library define an ISR for the interrupt vector "TIMER1_COMPA_vect" that
//    operates according to following steps:
//        a) call the PIH of any SCHEDULE that is "right on time"  to be called
//           (including those that are just a little early or late);
//           If necessary, the SCHEDULE of those PIH called at this step has their parameter
//           "Number of Times that it must be called" decreased (and saved in SCHEDLUDE's
//           "MT_schedule[].count"). Then, if this number reachs value 0x0, the SCHEDULE
//           is excluded from Timer/Counter1 schedule control;
//        b) for all SCHEDULES, the next time interval required to call the SCHEDULE's PIH is
//           calculated (and saved into "MT_schedule[].triggerticks") ;
//        c) the SCHEDULE which PIH must be called first (before the others
//           SCHEDULES), the so called NEXT_SCHEDULE, is searched;
//        d) the time interval required to call NEXT_SCHEDULE's PIH (saved in
//           SCHEDULE's "MT_schedule[].triggerticks") is loaded in Timer/Counter1 OCR1A
//           register (and in variable "TM_NextTriggerInterval);
//
//    For Arduino boards, the Arduino IDE usually assigns to a SKETCH the
//    Timer/Counter0 acting as a counter of the elapsed time since board's last reset
//    or start-up . Functions like "millis()" and "micros()" are based on it. So, if the
//    programmer convert this library to operate on Timer/Counter0, he/she can not use
//    Timer/Counter0 without special care/approach.
//
//    IMPORTANT:
//    because this library has an ISR with 'long' execution time (for an ISR) it may
//    affect functions like 'millis()' and 'micros()'. Those affected functions
//    depends on Timer/Counter0. But this library requires to disable interruptions
//    (using 'cli()' function) for some moment. During this moment, function "micros()"
//    can loose a TCNT0 overflow and return a fake (less than the real) value.
//    I believe that this lost of TCNT0 overflow will occur if the interval between
//    the call of "cli()" and "sei()" is approximately greater or equal to 2 us.
//
//
//    Steps to use this library:
//      A) At the boot, to configure timer before run main program:
//        *  In the header file "MultiTimer_ISR.h", change the number "10" from directive code line
//           "#define MultiTimersLimit  (10)" , to the maximum number of SCHEDULES that the programmer
//           plans to use simultaneously;
//        *  Use "MT_IncludeSchedule()" to include at least one SCHEDULE;
//        *  Enable Timer/Counter 1 operating in CTC mode (Clear Timer on Compare Match) by running "MT_SetCTCmode()".
//        *  If needed, variables "T_PrescalerPrecision" and "MT_uCCycleSafeGuard" may be changed in file "MultiTimer_ISR.cpp".
//               -) "T_PrescalerPrecision" is a 'per thousand' (percentage multiplied by 10) tolerance accepted by
//                   programmer as the maximum delay interval to call a PIH or early advance to call a PIH;
//               -) "MT_uCCycleSafeGuard" is an estimation of how many microcontroller clock cycles is required to run
//                   ISR(TIMER1_COMPA_vect) and any called PIH; - it is used to avoid (when possible) overlap of PIH call-
//        *  Once there is at least one included SCHEDULE, run "MT_SelectPrescalerDivisor()";
//        *  After run "MT_SelectPrescalerDivisor()", call "MT_SetClockSource()" to configure Timer/Counter1 Prescaler
//           output ticks frequency, i.e. Timer1 output clock frequency ;
//        *  After run "MT_SetClockSource()", call "MT_SetSchedulesTicks()" to convert SCHEDULE's periods (in
//           microseconds) to correspondent Timer/Counter1 Prescaler output ticks;
//        *  After run "MT_SetSchedulesTicks()", call  "MT_AlignSchedules()" to synchronize SCHEDULEs with its
//           required offsets. This will introduce delay before the first call of its PIH.
//        *  After run "MT_AlignSchedules()", call "MT_PrepareOCR()" to allow Timer/Counter1 make its first PIH call
//           at the right moment (without overflow TCNT1);
//        *  After run "MT_PrepareOCR()", call "MT_StartMultiTimer()" to start Timer/Counter1 act like a MultiTimer.
//
//      B) After main program start running, call "MT_NewSchedule()" to include new schedule.
//
//      C) In prototypes, to help the search for bugs, variables "MT_LostPIHCall" and "MT_Tcnt1Overflow" may be
//         verified (periodically or eventually) while this sample program is already running.
//
//      IMPORTANT: no function of this library can be called inside an PIH or another real ISR.
//                 The "ISR(TIMER1_COMPA_vect)" and other functions allows nested interrupts. Functions like
//                 "MT_ScheduleCounterDec" , "MT_ExcludeSchedule()" , "MT_NewSchedule()" may corrupt 'MT_schedule[]'
//                 array data if another one of these change the number (and position) of elements in this array.
//                 It is possible to any PIH or real ISR set a flag to the main Sketch function ( "loop()" ). This
//                 function, in its turn, can call required function of this library.
//
//################################################################################### //


/*   Desired improvements:
/    *) in function "MT_ExcludeCounterZero", if the command line " if (MT_timersRunning == 0)  MT_StopMultiTimer(); "
/        is uncommented, the program can NOT lead Timer/Counter1 to  work properly again. Even knowing that function
/        "MT_StartMultiTimer()" necessary to make Arduino work properly in the beginning, this function seems to
/        be NOT able to restore normal operation after a call to "MT_StopMultiTimer()".
/    *) the function "MT_ExcludeSchedule()" must be tested.
/    *) In function "MT_IncludeSchedule()", the default value for parameter "ofstID" must be changed to "0" (zero),
/       because "0" will never be assigned to struct member "id" of any SCHEDULE. Then, this change must be propagated
/       through all the program (where the default value may be assigned to other variables) or the struct member "id"
/       either variables that received value from "id" or will pass its value to "id" are compared to the default value.
*/


#ifndef _MULTITIMER_ISR_H_
#define _MULTITIMER_ISR_H_

#include <Arduino.h>

//-----  Programmer configurable parameters:  ------

    // Macro 'MultiTimersLimit' defines the total of Pseudo Interrupt Handler - PIH that can be scheduled to Timer/Counter1.
#if !(defined(MultiTimersLimit))
     #define MultiTimersLimit  (5)
#endif  // !(defined(MultiTimersLimit))
extern const uint8_t  MT_scheduleslimit;  // Maximum number of schedules that the library will handle simultaneously.
    // WARNING: large values for variable MT_scheduleslimit may require much longer time to process the main Interrupt
    //          Service Routing of Timer/Counter1, i.e. "ISR(TIMER1_COMPA_vect)". As consequence, lower periods (high
    //          frequency) schedules may be affected. In this case, variable "MT_uCCycleSafeGuard" (and maybe
    //          "MT_PrescalerPrecision") may be adjusted (increased).
//------------------------------------------------

//-----  Hardware parameters:  ------
    // All variables bellow must be present for any Arduino board, but its values must be adjusted according the microcontroller's specifications.
    // Values presented here are adjusted to AVR ATmega328P.
extern const uint32_t MT_CpuFreq;   // Frequency of the microcontroller (clk i/o), in hertz.
extern const uint8_t  MT_PrescalerNumb; // Total number of options available to set the prescaler divisor value in which MCU frequency will be divided.
extern const uint16_t MT_PrescalerDivVal[]; // Prescaler Divisor Valuers for MCU frequency. Values must be in ascending order. Data type must be able to hold the greatest Prescaler Divisor Valuer.
extern const uint8_t  MT_PrescalerCS1Msk ;  // A mask for bits (CS12, CS11 and CS10) inside the register in which prescaler divisor value is configured ("TCCR1B"). This variable data type must be the same as "TCCR1B" register and in its value all bits CS12, CS11 and CS10 must be set as well as all other bits must be clear (reset).
extern const uint8_t  MT_PrescalerCS1Val[] ;   // This variable data type must be the same as the register in which prescaler divisor value is configured ("TCCR1B"). Each element of this array has the value in which "TCCR1B" (bits CS12, CS11 and CS10) must be set, according the respective element in "MT_PrescalerDivVal[]" .
                       // Logical operation OR is applied over this array values and register "TCCR1B" value, to configure TCCR1B bits CS12, CS11 and CS10 according to correspondent elements in "MT_PrescalerDivVal[]" array (correspondent prescaler divisor values).

/*
AVR ATmega328P with 16MHz Frequency, leads to the following ste of prescaler output frequencies and respective prescaler divisor value {
    tck_62_5ns :    1 ,    // 62.5E-9 seconds for F_CPU equals to 16000000 Hz.
    tck_500ns  :    8 ,    //  500E-9 seconds for F_CPU equals to 16000000 Hz.
    tck_4us    :   64 ,    //  4.0E-6 seconds for F_CPU equals to 16000000 Hz.
    tck_16us   :  256 ,    // 16.0E-6 seconds for F_CPU equals to 16000000 Hz.
    tck_64us   : 1024 ,    // 64.0E-6 seconds for F_CPU equals to 16000000 Hz.
};
*/
//----------------------------------------------


//-----  Library configurable parameters:  ------
    // This parameter may be changed if required to application specificities.
typedef uint8_t  MT_repeat_type;     // At least an unsigned data type with 8 bit size.
typedef uint32_t MT_interval_type;   // Must be a data type with, at least, 20 bits. Capable to represent, at least, 1 million microseconds.
typedef uint16_t MT_ticks_type;      // Must be a data type capable of storing any value from TCNT1 or OCR1A registers.
typedef uint16_t MT_id_type;         // At least an unsigned data type with 8 bit size.

extern uint8_t MT_PrescalerPrecision;  // The precision of the time interval in which the PIH with the minimal scheduled period
                                       //     will be called is defined in multiples of 1/1000th of that PIH's period.
                                       //      E.g., if the PIH with minimal scheduled period has a value of 5000 microseconds but the
                                       //      application allows a maximum tolerance of +/- 275 microseconds, the value of variable
                                       //     "MT_PrescalerPrecision" must be set as : (275/5000)*1000 . This value is the percentage
                                       //     of the tolerance multiplied by 10.
                                       //     Other factor may delay the call even more, like execution of routines that disable interruption.
                                       //     In situations when range of PIH periods scheduled are very wide, and no Prescaler Divisor Value are compatible,
                                       //     the value of "MT_PrescalerPrecision" may be lowered to (try to) allow a valid Prescaler Divisor Value.
extern uint16_t MT_PrescalerDivisor; // Prescaler Divisor Value selected automatically by the library, according to actual range of PIH period schedules. Data type must be the same as "MT_PrescalerDivVal[]" array elements.
extern float MT_Timer1Period;        // Period of the frequency supplied by Prescaler to Control Logic, measured in microseconds.
//----------------------------------------------



//    Library parameters and function (non configurable):

typedef struct ts {

    // Library controlled parameters.
    MT_id_type id;                    // ID supplied by MultiTimer Scheduler to identify a Pseudo Interrupt Handler. It allow the programmer to exclude the Pseudo interrupt Handler.

    // Programmer supplied parameters to include a schedule to Timer/Counter 1.
    MT_interval_type period;          // Period between consecutive calls to this PIH, in microseconds;
    MT_repeat_type repeat;            // Number of times that Pseudo Interrupt Handler will run, as initially defined by programmer.
    void (* pih_func_ptr)(void);      // A pointer to the Pseudo Interrupt Handler.

    MT_interval_type offsetinterval;  // Delay interval, in microseconds, from another PIH call to allow synchronism but change the phase.
    MT_id_type offsetid;              // ID supplied by MultiTimer Scheduler to another PIH used as offset interval reference.

    // Library controlled parameters.
    MT_ticks_type periodticks;        // Period between consecutive calls to its PIH, in prescaler ticks.

    // Runtime (changing) parameters controlled by Timer/Counter 1 ISR.
    MT_ticks_type triggerticks;       // Number of prescaler ticks that must be elapsed before its PIH function be called.
    MT_repeat_type counter;           // Number of times that Pseudo Interrupt Handler will still be running by the application.

} MTlog;

extern MTlog volatile MT_schedule[];    // Has the initial parameters supplied by the programmer to schedule any PIH.
extern MT_interval_type MT_maxInterval;    // Maximum period (in microseconds) among all Pseudo Interruption Handlers included in the schedule of Timer/Counter 1 .
extern MT_interval_type MT_minInterval;    // Minimum period (in microseconds) among all Pseudo Interruption Handlers included in the schedule of Timer/Counter 1 .
extern MT_repeat_type volatile MT_timersRunning;      // Total number of Pseudo Interrupt Handler function actually scheduled by Timer/Counter 1 interruptions.

extern uint16_t volatile MT_TicksSafeGuard;  // Minimum amount of prescaler ticks that will be available to MCU between consecutive Timer/Counter 1 ISR call.
// Avoid the loss of next (Timer/Counter1) Interrupt call because OCR1A was written with a small value that could let TCNT1 surpass it (before the OCR1A get written) and overflow before next Interrupt call.
// when the time interval between two consecutive PIH call (whether or not the PIH's function called is the same) is lesser than time required to process all instructions of Timer/Counter1's ISR plus the first called PIH's function,
// the second called PIH will be inevitably delayed. In this case if this time interval between two consecutive PIH call is used to write OCR1A value, this could happen when TCNT1 has surpassed this value and no PIH will be called before Timer/Counter 1 overflow.
// The value of this variable depends on: Timer/Counter1 prescaler (and mcu clock frequency), "MT_scheduleslimit" value (or more precisely "MT_timersRunning"),
// instruction cycles required to run interrupt handling function " MT_UpdateNextTrigger()", instruction cycles required to run (all) PIH functions, etc.
//* volatile * /

extern uint16_t MT_uCCycleSafeGuard;  // Minimum amount of clock cycles that will be used as a "tolerance value" to decide if a PIH's call that
                                           //     may be late or early (compared to time in Timer/Counter1 TCNT1 register) will (or NOT) be executed
                                           //     right now by "TIMER1_COMPA_vect" ISR.
                                           // The value of this variable may be the total ammount of clock cycles required to run only the
                                           //     "TIMER1_COMPA_vect" ISR or the sum of the clock cycles of "TIMER1_COMPA_vect" ISR and
                                           //     all PIH.

extern MT_repeat_type volatile MT_LostPIHCall;     // Number of times that a PIH function should be called but wasn't.
                                                //     This may happen because a schedule my have a very small "periodticks" or another
                                                //     schedule have a PIH execution time too long.
                                                //     If the case of a conflict of a schedule with small "periodticks" with a  second
                                                //     schedule with long PIH execution time, the problem shall be solved  by using
                                                //     function "sei()" inside the PIH function of the schedule with long PIH execution
                                                //     time to allow nested interrupts.

extern MT_repeat_type volatile MT_Tcnt1Overflow;   // Number of time that Timer/Counter1 have overflowed.
extern bool volatile Tmr1COMPA;   // Flag that may be used to indicate that a "Compare on Match A event" of Timer/Counter1 is running its ISR.
                           //     This may be interesting if "Compare on Match A" ISR allows nested interrupts. Specially if one
                           //     interrupt that runs "inside" the "Compare on Match A" ISR can call any function of this MultiTimer
                           //     library.

void MT_SetCTCmode(void);
int8_t MT_SelectPrescalerDivisor(void);
int8_t MT_SetClockSource(void);
bool MT_PrepareOCR(void);
bool MT_StartMultiTimer(void);
void MT_StopMultiTimer(void) ;

unsigned int MT_TCNT1Read( void );
void MT_TCNT1Write( unsigned int i);
unsigned int MT_OCR1ARead( void );
void MT_OCR1AWrite( unsigned int i );
unsigned int MT_OCR1BRead( void );
void MT_OCR1BWrite( unsigned int i );
unsigned int MT_ICR1Read( void );
void MT_ICR1Write( unsigned int i );

int8_t MT_IncludeSchedule( MT_interval_type interval, void (*PseudoInterruptHandler)(),
                         uint8_t countdown=(MT_repeat_type)(~0x00), MT_id_type *PIH_id=0,
                         MT_interval_type offset=0, MT_id_type ofstID = ((MT_id_type)(~0x0)) );
int8_t MT_SetSchedulesTicks(MT_id_type *PIH_id=0);
int8_t MT_AlignSchedules(MT_id_type *PIH_id=0, uint8_t absolutedelay=1u);
int8_t MT_ExcludeSchedule(MT_id_type exID);
int8_t MT_ExcludeCounterZero(void);
int8_t MT_ScheduleCounterDec(MT_id_type Sched_id, MT_repeat_type val = 1u);
int MT_ExecSchedulesPIH();

int8_t MT_NewSchedule( MT_interval_type interval, void (*PseudoInterruptHandler)(),
                         uint8_t countdown=(MT_repeat_type)(~0x00), MT_id_type *PIH_id=0,
                         MT_interval_type offset=0, MT_id_type ofstID = ((MT_id_type)(~0x0)),
                         uint8_t absolutedelay=1u );


#endif // _MULTITIMER_ISR_H_


/** /


//------ CODE example: SIMPLE APPLICATION ------//
// Four independent ('software') Timers plus one independent ('software') PWM.
// To this example code, 5 LEDs (common cathode) must be used.
// Anodes terminal connects to Arduino's pins: 8, 9, 10, 11, 12. Common cathode connects to Arduino's pin GND.
// Two ('software') Timers (pins 9 and 10) are synchronized and other Timer (pin 11) will toggle its output only 8 times (in.
// the first 16 seconds of runtime) before the program enters an infinite loop. Inthis loop, a new ('software') Timer is
// included every 8 seconds, making pin 11 toggle its output 16 times (four seconds blinking, four seconds off).

#include <MultiTimer_ISR.h>

void Set_PB_Outputs(void) {
    uint8_t sreg = SREG;
    cli();

    DDRB |= (1 << PB0);   // Arduino pin 8  (AVR ATmega328P pin PB0) is an output.
    DDRB |= (1 << PB1);   // Arduino pin 9  (AVR ATmega328P pin PB1) is an output.
    DDRB |= (1 << PB2);   // Arduino pin 10 (AVR ATmega328P pin PB2) is an output.
    DDRB |= (1 << PB3);   // Arduino pin 11 (AVR ATmega328P pin PB3) is an output.
    DDRB |= (1 << PB4);   // Arduino pin 12 (AVR ATmega328P pin PB3) is an output.

    PORTB  = 0x0;   // All AVR Atmeg328P Port B pins are cleared.

    SREG = sreg;
}

void PIH_PB0(void) {
    uint8_t sreg = SREG;
    cli();

    PORTB ^= (1 << PB0);

    SREG = sreg;
}

void PIH_PB1(void) {
    uint8_t sreg = SREG;
    cli();

    PORTB ^= (1 << PB1);

    SREG = sreg;
}

void PIH_PB2(void) {
    uint8_t sreg = SREG;
    cli();

    PORTB ^= (1 << PB2);

    SREG = sreg;
}

void PIH_PB3(void) {
    uint8_t sreg = SREG;
    cli();

    PORTB ^= (1 << PB3);

    SREG = sreg;
}

void PIH_PB4_PWM(void) {
    // Generates a train of pulses with shape similar to a PWM wave modulated by a triangular wave.
    //     The PWM pulse period is defined by: (pwm_tmr_mx + 1) * (PIH_PB4_SCHEDULE_period [in microseconds])
    //     The triangular wave frequency is defined by:  '2 * signal_periodmult * ((pwm_tmr_mx + 1) * (PIH_PB4_SCHEDULE_period [in microseconds]) )'

    //--- Define PWM pulse parameters:
    uint8_t pwm_tmr_mx = 30;          // Maximum value allowed for "pwm_tmr".
                                      //     The period of the pseudo PWM Wave pulse generated by "pwm_tmr_max" is: '(pwm_tmr_mx + 1) * PIH_PB4_SCHEDULE_period' .
                                      //     Sugested period is equal or smaller than 20 mili seconds.
                                      //     It also define the quatization levels for variables "pwm_tmr" and "adjusted_level".
    static uint8_t pwm_tmr = 0u;      // Counter (equivalent to a timer that sets the period of a PWM constant frequency wave). Value limits = [0 ; pwm_tmr_mx]
                                      // It counts the number of times this function "PIH_PB4_PWM()" was called.


    static bool directionUp = true;   // Direction of "signallevel". Value "true" will increase "signallevel", while "false" will decrease.

    //--- Define tha parametes of the modulator signal for the PWM pulses:
    uint8_t signal_periodmult = 160; // Number of PWM pulses required to the pseudo triangular wave reach its maximum value, starting counting by its lowest value ("0").
    static uint8_t signallevel = 0u;  // Meam voltage of output signal pin. It works like a triangular wave. Value limits = [0%; 100%];
                                      //     The period of the pseudo triangular wave is:
                                      //  '2 * signal_periodmult * ((pwm_tmr_mx + 1) * PIH_PB4_SCHEDULE_period)' .
    uint8_t adjustedlevel = 0u;       // Variable "signal_periodmult" defines the period of the pseudo triangular wave generated in "signallevel".
                                      //     But, to control the mean voltage value of output pin, "signallevel" value must be converted to the same range
                                      //     used by "pwm_tmr" variable ([0 ; pwm_tmr_mx]). This conversion is made in "adjustedlevel".
                                      //     Carefull must be taken to avoid problems of data type conversion/compatibility when "signal_periodmult" value is
                                      //     smaller than "pwm_tmr_mx" value. It extreme cases, variables "adjustedlevel", "pwm_tmr" and "pwm_tmr_mx" must have
                                      //     data type "uint16_t".

    uint8_t sreg;

    sreg = SREG;
    sei();

    adjustedlevel = ( ((uint16_t)signallevel) * pwm_tmr_mx) / signal_periodmult;
    // float flatlevel = ( ((float)signallevel)/ signal_periodmult); flatlevel *= flatlevel; flatlevel*= pwm_tmr_mx; adjustedlevel = flatlevel;

    //--- Detect PWM pulse's end of duty-cycle.
    if (pwm_tmr >= adjustedlevel) {
        cli();
        PORTB &= ~(1 << PB4);
        SREG = sreg;
    }

    //--- Increase PWM timer.
    ++pwm_tmr;

    //---Detect end of PWM pulse.
    if (pwm_tmr > pwm_tmr_mx) {
        //--- Reset PWM timer.
        pwm_tmr = 0u;

        //--- Set PWM pulse's duty-cycle start.
        cli();
        if (adjustedlevel > 0) PORTB |= (1 << PB4);
        SREG = sreg;

        //--- Calculate the value of PWM modulator signal to the next PWM pulse
        if (directionUp) {
            ++signallevel;  // Increase modulator signal for triangular wave.
            //--- Detect and set the end of rising part of modulator signal
            if (signallevel > signal_periodmult){
                signallevel = signal_periodmult -1;  // Decrease modulator signal for triangular wave.
                directionUp = false;
            }
        } else {
            --signallevel; // Decrease modulator signal for triangular wave.
            //--- Detect and set the beginning of rising part of modulator signal
            if (signallevel == 0u) directionUp = true;
        }
    }

    SREG = sreg;
}

bool Startup_Error = false;

void Startup_Serial(void) { Serial.begin(9600, SERIAL_8N1); }

void SetStartupError(char const *txt, int8_t r){
    Serial.print("ERROR: ");
    if (txt != 0x0) {
        Serial.print(txt);
        Serial.print(" returned ");
    }
    Serial.print(r);
    Serial.println(" .");
    Startup_Error = true;
    return;
}

bool SetAllSchedules(void) {
    int8_t r;

   // Prototype of function "MT_IncludeSchedule()":
   // MT_IncludeSchedule( MT_interval_type interval, void (*PseudoInterruptHandler)(),
   //                      uint8_t countdown=((MT_repeat_type)(~0x00)), MT_id_type *PIH_id=0,
   //                      MT_interval_type offset=0, MT_id_type ofstID = ~(0U) )
    MT_id_type SynchID;
    r = MT_IncludeSchedule( 375000UL, &PIH_PB0);
    if (r < 0) { SetStartupError("MT_IncludeSchedule() [first time]", r); return false;}

    r = MT_IncludeSchedule( 1000000UL, &PIH_PB1, (MT_repeat_type)(~0x00), &SynchID );  // The ID given to the SCHEDULE of PIH_PB1 is saved in SynchID to synchonize the SCHEDULE of PIH_PB2.
    if (r < 0) { SetStartupError("MT_IncludeSchedule() [second time]", r); return false;}

    r = MT_IncludeSchedule( 1000000UL, &PIH_PB2, (MT_repeat_type)(~0x00),      0x0, 500000L, SynchID );  // PIH_PB2 is synchonized with PIB_PB1, but with a delay of 400.000 microseconds.
    if (r < 0) { SetStartupError("MT_IncludeSchedule() [third time]", r); return false;}

    r = MT_IncludeSchedule(1665000UL, &PIH_PB3, 6);
    if (r < 0) { SetStartupError("MT_IncludeSchedule() [fourth time]", r); return false;}

    r = MT_IncludeSchedule(650UL, &PIH_PB4_PWM, 0x0);
    if (r < 0) { SetStartupError("MT_IncludeSchedule() [fifth time]", r); return false;}

    return true;
}

bool ConfigureMultiTimer(void) {
    int8_t r;

    //--- Include (at least one) SCHEDULES.
    if (SetAllSchedules() == false) { SetStartupError("SetAllSchedules()", 0); return false;}

    //--- Enable Timer/Counter 1 to operate in CTC mode (Clear Timer on Compare Match).
    MT_SetCTCmode();

    //--- Configure Timer/Counter1 Prescaler
    r = MT_SelectPrescalerDivisor(); //  Configure the best value of Prescaler Divisor based on existing SCHEDULES.
    if (r < 0) { SetStartupError("MT_SelectPrescalerDivisor()", r); return false;}

    r = MT_SetClockSource(); //  Configure Timer/Counter1 clock frequency based on existing SCHEDULES.
    if (r < 0) { SetStartupError("MT_SetClockSource()", r); return false;}

    r = MT_SetSchedulesTicks(); //  Convert SCHEDULE's "period" parameter (defined in microseconds) to corresponding number of Timer/Counter1 Prescaler output ticks.
    if (r < 0) { SetStartupError("MT_SetSchedulesTicks()", r); return false;}

    r = MT_AlignSchedules(); //  Introduct offset delay in the first call of SCHEDULES' PIH that requires synchronization.
    if (r < 0) { SetStartupError("MT_AlignSchedules()", r); return false;}

    //--- Prepare Timer/Counter 1 to call the first PIH, loading the appropriate value int OCR1A.
    if (MT_PrepareOCR() == false) { SetStartupError("MT_PrepareOCR()", 0); return false;}

    return true;
}

void Print_SetupParameters(void) {
      Serial.print("Maximum allowed SCHEDULES: "); Serial.println(MT_scheduleslimit);
      Serial.print("SCHEDULES included in MultiTimer_ISR: "); Serial.println(MT_timersRunning);
      Serial.print("CPU frequency: "); Serial.println(MT_CpuFreq);
      Serial.print("Maximum period of all SCHEDULES: "); Serial.print(MT_maxInterval); Serial.println(" [microseconds]");
      Serial.print("Minimum period of all SCHEDULES: "); Serial.print(MT_minInterval); Serial.println(" [microseconds]");
      Serial.print("Timer/Counter 1 Prescaler divisor applied to CPU clock frequency: "); Serial.println(MT_PrescalerDivisor);
      Serial.print("Period of Timer/Counter1 Prescaler output ticks: "); Serial.print(MT_Timer1Period);  Serial.println(" [microseconds]");
      Serial.print("Timer precision: "); Serial.print(MT_PrescalerPrecision/10); Serial.print("% of the smallest period : ");
          Serial.print(MT_minInterval * MT_PrescalerPrecision/1000); Serial.println(" [microseconds]");
      Serial.print("Actual valid (or minimum allowed) value for MT_uCCycleSafeGuard: "); Serial.print(MT_uCCycleSafeGuard);
          Serial.print(" clock cycles  = "); Serial.print(MT_TicksSafeGuard * MT_Timer1Period); Serial.println(" microseconds");
}

void Print_FaultParameters(void) {
      Serial.print("Number of times that a PIH should be called but, because ISR(TIMER1_COMPA_vect) and other PIH may have a long execution time, it could not: "); Serial.println(MT_LostPIHCall);
      Serial.print("Number of times that Timer/Counter1 TCNT1 overflow occurred without call any PIH (because value loaded into OCR1A was lower than the current value of TCNT1): "); Serial.println(MT_Tcnt1Overflow);
}

void Print_SchedulesCounter() {
    for (uint8_t k=0; k < MT_timersRunning; ++k) {
        Serial.print("SCHEDULE["); Serial.print(k); Serial.print("] => ");
        Serial.println(MT_schedule[k].counter);
    }
}

void setup(void){
    //--- Configure output pins.
    Set_PB_Outputs();

    //--- Enable Serial Monitor communications
    Startup_Serial();

    //--- Configure MultiTimer
    MT_uCCycleSafeGuard = 1320; // For a limit of 5 SCHEDULEs the default value to "MT_uCCycleSafeGuard"
                                //     would be 2603. But this value can be decreased if:
                                //       *) the "Number of times that a call to any PIH function could
                                //          NOT be executed" (stored in variable "MT_LostPIHCall") keeps
                                //          its value to "0" (during all the time that the microcontroller
                                //          is powered on);
                                //       *) the "Timer precision" ( 'MT_minInterval * MT_PrescalerPrecision/1000' )
                                //          is still greater than 'MT_TicksSafeGuard * MT_Timer1Period' .
    if (ConfigureMultiTimer() == false) {
      Startup_Error = true;
    }
    Print_SetupParameters();

    //--- Startup MultiTimer
    if (MT_StartMultiTimer() == false) {SetStartupError("MT_StartMultiTimer()", false); }

}

void loop (void) {
    int8_t r;

    Serial.println("\n>>Running...");
    Print_FaultParameters();
    Print_SchedulesCounter();

    delay(4000);
    Print_FaultParameters();
    Print_SchedulesCounter();

    delay(4000);
    Print_FaultParameters();
    Print_SchedulesCounter();

    delay(6000);

    do {    // Infinit loop.
        r = MT_NewSchedule(500000UL, &PIH_PB3, 6);
        if (r < 0) { SetStartupError("MT_NewSchedule()", r); }    // Serial.print("MT_NewSchedule() returned value: "); Serial.println (r);
        Print_FaultParameters();
        Print_SchedulesCounter();
        delay(6000);
        Serial.println();
        Print_SchedulesCounter();
    } while (true);
}

/**/

