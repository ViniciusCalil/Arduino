//###############################    MultiTimer ISR    ############################## //
//
//   Author:  Vinicius Calil
//   Date:   december/2020
//
//   Objective: Share one single microcontroller's timer among many independent
//              interrupt handling function. I.e., transform a single hardware
//              timer in many software timers.
//   Hardware: Arduino UNO
//   Compiler: AVR GCC
//
//
//   Description:
//
//    Although Timer/Counter1 supports four different functions as Interrupt Service
//    Routine-ISR (TIMER1 CAPT, TIMER1 COMPA, TIMER1 COMPB and TIMER1 OVF) some times
//    an application may require only simple operation like "TIMER1 COMPA" ISR, but
//    for many completely independent functions.
//    This header file allows multiple functions (hereby called Pseudo Interrupt
//    Handler-PIH) to be scheduled, each one with its own independent time interval
//    requirements, in Timer/Counter1 "TIMER1 COMPA" ISR. In this way, Timer/Counter1
//    hardware is shared among multiple PIH and behaves like the microcontroller has
//    a lot of timers available.
//
//    The programmer may INCLUDE many functions "Pseudo Interrupt Handler-PIH" to the
//    Timer/Counter1's schedule control by passing, at least, a function pointer
//    (pointed to the desired PIH) and a time interval between consecutive interrupt
//    calls to this PIH. The 'struct' created when a PIH is included in Timer/Counter1's
//    schedule control is referred as a "SCHEDULE".
//    Any SCHEDULE may ALSO be supplied with the following information: number of times
//    that its PIH must be called, the ID of another SCHEDULE used to synchronize the new
//    one that is being included, and a delay/off-set interval between the interrupt call of
//    the new included PIH and the other PIH used to synchronize the new one.
//
//    This library sets Timer/Counter1 in Clear Timer on Compare Match (CTC) Mode with
//    TOP set to OCR1A. The interrupt vector "TIMER1_COMPA_vect" is called every time
//    TCNT1 is equal to OCR1A.
//    This library define an ISR for the interrupt vector "TIMER1_COMPA_vect" that
//    operates according to following steps:
//        a) call the PIH of any SCHEDULE that is "right on time"  to be called
//           (including those that are just a little early or late);
//           If necessary, the SCHEDULE of those PIH called at this step has their parameter
//           "Number of Times that it must be called" decreased (and saved in SCHEDLUDE's
//           "MT_schedule[].count"). Then, if this number reachs value 0x0, the SCHEDULE
//           is excluded from Timer/Counter1 schedule control;
//        b) for all SCHEDULES, the next time interval required to call the SCHEDULE's PIH is
//           calculated (and saved into "MT_schedule[].triggerticks") ;
//        c) the SCHEDULE which PIH must be called first (before the others
//           SCHEDULES), the so called NEXT_SCHEDULE, is searched;
//        d) the time interval required to call NEXT_SCHEDULE's PIH (saved in
//           SCHEDULE's "MT_schedule[].triggerticks") is loaded in Timer/Counter1 OCR1A
//           register (and in variable "TM_NextTriggerInterval);
//
//    For Arduino boards, the Arduino IDE usually assigns to a SKETCH the
//    Timer/Counter0 acting as a counter of the elapsed time since board's last reset
//    or start-up . Functions like "millis()" and "micros()" are based on it. So, if the
//    programmer convert this library to operate on Timer/Counter0, he/she can not use
//    Timer/Counter0 without special care/approach.
//
//    IMPORTANT:
//    because this library has an ISR with 'long' execution time (for an ISR) it may
//    affect functions like 'millis()' and 'micros()'. Those affected functions
//    depends on Timer/Counter0. But this library requires to disable interruptions
//    (using 'cli()' function) for some moment. During this moment, function "micros()"
//    can loose a TCNT0 overflow and return a fake (less than the real) value.
//    I believe that this lost of TCNT0 overflow will occur if the interval between
//    the call of "cli()" and "sei()" is approximately greater or equal to 2 us.
//
//
//    Steps to use this library:
//      A) At the boot, to configure timer before run main program:
//        *  In the header file "MultiTimer_ISR.h", change the number "10" from directive code line
//           "#define MultiTimersLimit  (10)" , to the maximum number of SCHEDULES that the programmer
//           plans to use simultaneously;
//        *  Use "MT_IncludeSchedule()" to include at least one SCHEDULE;
//        *  Enable Timer/Counter 1 operating in CTC mode (Clear Timer on Compare Match) by running "MT_SetCTCmode()".
//        *  If needed, variables "T_PrescalerPrecision" and "MT_uCCycleSafeGuard" may be changed in file "MultiTimer_ISR.cpp".
//               -) "T_PrescalerPrecision" is a 'per thousand' (percentage multiplied by 10) tolerance accepted by
//                   programmer as the maximum delay interval to call a PIH or early advance to call a PIH;
//               -) "MT_uCCycleSafeGuard" is an estimation of how many microcontroller clock cycles is required to run
//                   ISR(TIMER1_COMPA_vect) and any called PIH; - it is used to avoid (when possible) overlap of PIH call-
//        *  Once there is at least one included SCHEDULE, run "MT_SelectPrescalerDivisor()";
//        *  After run "MT_SelectPrescalerDivisor()", call "MT_SetClockSource()" to configure Timer/Counter1 Prescaler
//           output ticks frequency, i.e. Timer1 output clock frequency ;
//        *  After run "MT_SetClockSource()", call "MT_SetSchedulesTicks()" to convert SCHEDULE's periods (in
//           microseconds) to correspondent Timer/Counter1 Prescaler output ticks;
//        *  After run "MT_SetSchedulesTicks()", call  "MT_AlignSchedules()" to synchronize SCHEDULEs with its
//           required offsets. This will introduce delay before the first call of its PIH.
//        *  After run "MT_AlignSchedules()", call "MT_PrepareOCR()" to allow Timer/Counter1 make its first PIH call
//           at the right moment (without overflow TCNT1);
//        *  After run "MT_PrepareOCR()", call "MT_StartMultiTimer()" to start Timer/Counter1 act like a MultiTimer.
//
//      B) After main program start running, call "MT_NewSchedule()" to include new schedule.
//
//      C) In prototypes, to help the search for bugs, variables "MT_LostPIHCall" and "MT_Tcnt1Overflow" may be
//         verified (periodically or eventually) while this sample program is already running.
//
//      IMPORTANT: no function of this library can be called inside an PIH or another real ISR.
//                 The "ISR(TIMER1_COMPA_vect)" and other functions allows nested interrupts. Functions like
//                 "MT_ScheduleCounterDec" , "MT_ExcludeSchedule()" , "MT_NewSchedule()" may corrupt 'MT_schedule[]'
//                 array data if another one of these change the number (and position) of elements in this array.
//                 It is possible to any PIH or real ISR set a flag to the main Sketch function ( "loop()" ). This
//                 function, in its turn, can call required function of this library.
//
//
//################################################################################### //

/*   Desired improvements:
/    *) in function "MT_ExcludeCounterZero", if the command line " if (MT_timersRunning == 0)  MT_StopMultiTimer(); "
/        is uncommented, the program can NOT lead Timer/Counter1 to  work properly again. Even knowing that function
/        "MT_StartMultiTimer()" necessary to make Arduino work properly in the beginning, this function seems to
/        be NOT able to restore normal operation after a call to "MT_StopMultiTimer()".
/    *) the function "MT_ExcludeSchedule()" must be tested.
/    *) In function "MT_IncludeSchedule()", the default value for parameter "ofstID" must be changed to "0" (zero),
/       because "0" will never be assigned to struct member "id" of any SCHEDULE. Then, this change must be propagated
/       through all the program (where the default value may be assigned to other variables) or the struct member "id"
/       either variables that received value from "id" or will pass its value to "id" are compared to the default value.
*/


// #define _SAFEGUARDCHECK_
// #define _SAFEGUARDCHECK_Plus_

#include "MultiTimer_ISR.h"

#if defined( _SAFEGUARDCHECK_)
    #include <limits.h>
#endif // defined
//-----  Programmer configurable parameters:  ------

    // Macro 'MultiTimersLimit' defines the total of Pseudo Interrupt Handler - PIH that can be scheduled to Timer/Counter1.
const uint8_t  MT_scheduleslimit = MultiTimersLimit;  // Maximum number of schedules that the library will handle simultaneously.
    // WARNING: large values for variable MT_timersnumb may require much longer time to process the main Interrupt Service Routing of Timer/Counter 1.
    //          As consequence, lower periods (high frequency) schedules may be affected.
//------------------------------------------------

//-----  Hardware parameters:  ------
    // All variables bellow must be present for any Arduino board, but its values must be adjusted according the microcontroller's specifications.
    // Values presented here are adjusted to AVR ATmega328P.
const uint32_t MT_CpuFreq = F_CPU ;   // Frequency of the microcontroller (clk i/o), in hertz.
const uint8_t  MT_PrescalerNumb = 5U; // Total number of options available to set the prescaler divisor value in which MCU frequency will be divided.
const uint16_t MT_PrescalerDivVal[MT_PrescalerNumb] = {1U, 8U, 64U, 256U, 1024U}; // Prescaler Divisor Valuers for MCU frequency. Values must be in ascending order. Data type must be able to hold the greatest Prescaler Divisor Valuer.
const uint8_t  MT_PrescalerCS1Msk = (1 << CS12) | (1 << CS11) | (1 << CS10);  // A mask for bits (CS12, CS11 and CS10) inside the register in which prescaler divisor value is configured ("TCCR1B"). This variable data type must be the same as "TCCR1B" register and in its value all bits CS12, CS11 and CS10 must be set as well as all other bits must be clear (reset).
const uint8_t  MT_PrescalerCS1Val[MT_PrescalerNumb] = {1U, 2U, 3U, 4U, 5U};   // This variable data type must be the same as the register in which prescaler divisor value is configured ("TCCR1B"). Each element of this array has the value in which "TCCR1B" (bits CS12, CS11 and CS10) must be set, according the respective element in "MT_PrescalerDivVal[]" .
                       // Logical operation OR is applied over this array values and register "TCCR1B" value, to configure TCCR1B bits CS12, CS11 and CS10 according to correspondent elements in "MT_PrescalerDivVal[]" array (correspondent prescaler divisor values).

/*
AVR ATmega328P with 16MHz Frequency, leads to the following ste of prescaler output frequencies and respective prescaler divisor value {
    tck_62_5ns :    1 ,    // 62.5E-9 seconds for F_CPU equals to 16000000 Hz.
    tck_500ns  :    8 ,    //  500E-9 seconds for F_CPU equals to 16000000 Hz.
    tck_4us    :   64 ,    //  4.0E-6 seconds for F_CPU equals to 16000000 Hz.
    tck_16us   :  256 ,    // 16.0E-6 seconds for F_CPU equals to 16000000 Hz.
    tck_64us   : 1024 ,    // 64.0E-6 seconds for F_CPU equals to 16000000 Hz.
};
*/
//----------------------------------------------


//-----  Library configurable parameters:  ------
uint8_t MT_PrescalerPrecision = 100;     // The precision of the time interval in which the PIH with the minimal scheduled period
                                               // will be called is defined in multiples of 1/1000th of that PIH's period.
                                               // E.g., if the PIH with minimal scheduled period has a value of 5000 microseconds but the
                                               // application allows a maximum tolerance of +/- 275 microseconds, the value of variable
                                               // "MT_PrescalerPrecision" must be set as : (275/5000)*1000 . This value is the percentage
                                               // of the tolerance multiplied by 10.
                                               // Other factor may delay the call even more, like execution of routines that disable interruption.
                                               // In situations when range of PIH periods scheduled are very wide, and no Prescaler Divisor Value are compatible,
                                               // the value of "MT_PrescalerPrecision" may be lowered to (try to) allow a valid Prescaler Divisor Value.
uint16_t MT_PrescalerDivisor = 0; // Prescaler Divisor Value selected automatically by the library, according to actual range of PIH period schedules. Data type must be the same as "MT_PrescalerDivVal[]" array elements.
float MT_Timer1Period = 0;        // Period of the frequency supplied by Prescaler to Control Logic, measured in microseconds.
//----------------------------------------------



//    Library parameters and function (non configurable):

MTlog volatile MT_schedule[MT_scheduleslimit];    // Has the initial parameters supplied by the programmer to schedule any PIH.
MT_interval_type MT_maxInterval;    // Maximum period (in microseconds) among all Pseudo Interruption Handlers included in the schedule of Timer/Counter 1 .
MT_interval_type MT_minInterval;    // Minimum period (in microseconds) among all Pseudo Interruption Handlers included in the schedule of Timer/Counter 1 .
MT_repeat_type volatile MT_timersRunning = 0;      // Total number of Pseudo Interrupt Handler function actually scheduled by Timer/Counter 1 interruptions.

uint16_t volatile MT_TicksSafeGuard;  // Minimum amount of prescaler ticks that will be available to MCU between consecutive Timer/Counter 1 ISR call.
// Avoid the loss of next (Timer/Counter1) Interrupt call because OCR1A was written with a small value that could let TCNT1 surpass it (before the OCR1A get written) and overflow before next Interrupt call.
// when the time interval between two consecutive PIH call (whether or not the PIH's function called is the same) is lesser than time required to process all instructions of Timer/Counter1's ISR plus the first called PIH's function,
// the second called PIH will be inevitably delayed. In this case if this time interval between two consecutive PIH call is used to write OCR1A value, this could happen when TCNT1 has surpassed this value and no PIH will be called before Timer/Counter 1 overflow.
// The value of this variable depends on: Timer/Counter1 prescaler (and mcu clock frequency), "MT_scheduleslimit" value (or more precisely "MT_timersRunning"),
// instruction cycles required to run interrupt handling function " MT_UpdateNextTrigger()", instruction cycles required to run (all) PIH functions, etc.
uint16_t MT_uCCycleSafeGuard = 243 + (240 + 232) * MT_scheduleslimit;  // Value 243 is independent of SCHEDULES, 240 depend on SCHEDULES, 232 is a guess/supposition of mean clock cycles of all SCHEDULE's PIH run time.
                                           // Minimum amount of clock cycles that will be used as a "tolerance value" to decide if a PIH's call that
                                           //     may be late or early (compared to time in Timer/Counter1 TCNT1 register) will (or NOT) be executed
                                           //     right now by "TIMER1_COMPA_vect" ISR.
                                           // The value of this variable may be the total ammount of clock cycles required to run only the
                                           //     "TIMER1_COMPA_vect" ISR or the sum of the clock cycles of "TIMER1_COMPA_vect" ISR and
                                           //     all PIH.

MT_repeat_type volatile MT_LostPIHCall = 0;     // Number of times that a PIH function should be called but wasn't.
                                                //     This may happen because a schedule my have a very small "periodticks" or another
                                                //     schedule have a PIH execution time too long.
                                                //     If the case of a conflict of a schedule with small "periodticks" with a  second
                                                //     schedule with long PIH execution time, the problem shall be solved  by using
                                                //     function "sei()" inside the PIH function of the schedule with long PIH execution
                                                //     time to allow nested interrupts.
MT_repeat_type volatile MT_Tcnt1Overflow = 0;   // Number of time that Timer/Counter1 have overflowed.

//--- Flags
bool volatile MT_T1COMPArunning = false;   // Flag that may be used to indicate that a "Compare on Match A event" of Timer/Counter1 is running its ISR.
                           //     This may be interesting if "Compare on Match A" ISR allows nested interrupts. Specially if one
                           //     interrupt that runs "inside" the "Compare on Match A" ISR can call any function of this MultiTimer
                           //     library.
bool volatile MT_schedulefinished = false; // Flag that indicates when at least one SCHEDULE in "MT_schedule[]" had already been executed
                           //     all times it request. Then, these SCHEDULEs must be excluded.

void MT_SetCTCmode(void) {

    /*---- IMPORTANT: this part of this routine may be exclusive to ATmega 328P hardware. ----*/
    //           if your Arduino board has another processor, this routine may require some adjustments.*/

//  This function prepares the AVR ATmega328P Timer/Counter1 to work as a TIMER.

         /* Set CTC mode (Clear Timer on Compare Match) and TOP = OCR1A.  */
    TCCR1A = 0x0;
    TCCR1B = 0x0;
    TCCR1B |=  (1 << WGM12); // Set Timer/Counter 1 in CTC operation mode with OCR1A been the TOP value of TCNT1.
        /* Enable Timer/Counter 1 , Output Compare A Match Interrupt */
    TIMSK1 = 0x0;
//    TIMSK1 = (1 << OCIE1A) | (1 << TOIE1);  // The flag "TOIE1" is enabled to detect an OVERFLOW on TCNT1. This situation should never happen, an overflow means a failure of this algorithm to deal with PIH with very long execution time or schedules with very short "period" .

    /*---------------------------------------------------------------------------------------------*/
}

int8_t MT_SelectPrescalerDivisor(void) {
// This function reads the "period" member of all scheduled PIH and determine the best value
// to the Timer/Counter1 prescaler divisor, storing it to "MT_PrescalerDivisor" variable.

    MT_maxInterval = (MT_interval_type)0x00;
    MT_minInterval = ~MT_maxInterval;
    MT_interval_type intvlaux ;     // Data type of "intvlaux" must also be capable to handle all values of 'prescaler' divisors for MCU frequency.
    uint8_t prescaleridxmax = MT_PrescalerNumb - 1;   // Data type must be the same as "MT_PrescalerNumb".
    uint8_t prescaleridxmin = 0;    // Data type must be the same as "MT_PrescalerNumb".
    const MT_ticks_type MT_OCR1Amax = (MT_ticks_type)(~0x00);  // Maximum value that OCR1A can hold.
    float prescalerPeriod;
    uint8_t auxidx = 0;             // Data type must be the dsame as "MT_PrescalerNumb".

        /* Find minimum and maximum period required by any PIH */
    for (auxidx = 0; auxidx < MT_timersRunning; ++auxidx) {
        intvlaux = MT_schedule[auxidx].period;
        if (intvlaux > MT_maxInterval) MT_maxInterval = intvlaux;
        if (intvlaux < MT_minInterval) MT_minInterval = intvlaux;
    }

    /* Check minimum Prescaler Disivor Value able to deal with highest PIH period */
    //  The maximum period interval that a SCHEDULE's "periodticks" or "triggerticks" can hold
    //  depends on the minimum value of Prescaler Disivor Value, because those variables have
    //  limited data type size.
    do {
        prescalerPeriod = ((float)MT_PrescalerDivVal[prescaleridxmin]) / ((float)MT_CpuFreq);
        prescalerPeriod *= 1000000;    // Convert period in seconds to period in microseconds;
        if (MT_maxInterval < MT_OCR1Amax * prescalerPeriod) break;  // Condition "(MT_maxInterval/prescalerPeriod < MT_OCR1Amax)" must be satisfied to "intvlmax" and minimum prescaler divisor value.
        ++prescaleridxmin;
    } while ( prescaleridxmin < MT_PrescalerNumb );
    if ( prescaleridxmin == MT_PrescalerNumb ) return -1;  // No prescaler value allows "MT_OCR1Amax * prescalerPeriod" be greater than "intvlmax". This means that "intvlmax" is too high.
#if !defined( _SAFEGUARDCHECK_)
    if ( prescaleridxmin < (MT_PrescalerNumb - 1) ) ++prescaleridxmin; // This allows the SCHEDULEs to have a time offset at least equal to its period.
#endif // defined

    /* Check maximum Prescaler Disivor Value able to deal with smallest PIH period */
    do {
        prescalerPeriod = ((float)MT_PrescalerDivVal[prescaleridxmax]) / ((float)MT_CpuFreq);
        prescalerPeriod *= 1000000;    // Convert period in seconds to period in microseconds;
        if (prescalerPeriod * 1000 <= ((float)MT_minInterval) * MT_PrescalerPrecision) break;  // Condition "(prescalerPeriod <= MT_minInterval * MT_PrescalerPrecision / 1000 )" must be satisfied to "intvlmin" and maximum prescaler divisor value.
        --prescaleridxmax;
    } while ( prescaleridxmax < MT_PrescalerNumb );  // When a "0" value (of "prescaleridxmax") is decreased, once the data type is "unsigned", the underflow will bring "prescaleridxmax" value to its maximum data type value.
    if ( prescaleridxmax >= MT_PrescalerNumb ) return -2;  // No prescaler value allows "MT_minInterval" be greater or equal to "prescalerPeriod * MT_PrescalerPrecision". This means that "intvlmin" is too small.

    /* Check if maximum and minimum Prescaler Disivor Values are compatible with the range of PIH periods scheduled. */
    if (prescaleridxmin > prescaleridxmax) return -3; // The range of PIH periods scheduled are too wide. You may try to lower "MT_PrescalerPrecision" value (if it is not an issue to your application or, at least, to the smallers PIH period scheduled).

    /* Set Prescaler Disivor Values to the actual range of PIH periods scheduled. */
    if (prescaleridxmin < prescaleridxmax) {
        prescaleridxmax = (prescaleridxmin + prescaleridxmax) / 2; // This selects the middle value (or value immediately bellow, if the total of "MT_PrescalerDivVal" elements between index "prescaleridxmax" and "prescaleridxmin" are even).
    }
    MT_PrescalerDivisor = MT_PrescalerDivVal[prescaleridxmax];

    /* Check if the precision obtained (with selected "MT_PrescalerDivisor") is greatter or equal than (i.e. compatible with) MT_TicksSafeGuard . */
    prescalerPeriod = (((float)MT_PrescalerDivisor) / ((float)MT_CpuFreq) );   // Convert period in seconds to period in microseconds;
    MT_ticks_type MT_PrecisionTicks = ( ( ((float)MT_minInterval)/1000000 ) * MT_PrescalerPrecision )/(1000 * prescalerPeriod);
    MT_TicksSafeGuard = ( ((float)MT_uCCycleSafeGuard)/MT_CpuFreq ) / prescalerPeriod + 1;
    if ( MT_PrecisionTicks < MT_TicksSafeGuard) {
        // Doing "MT_PrecisionTicks == MT_TicksSafeGuard" in equation "MT_TicksSafeGuard = ( ((float)MT_uCCycleSafeGuard)/MT_CpuFreq ) / prescalerPeriod;"
        //     we get MT_uCCycleSafeGuard = MT_PrecisionTicks * prescalerPeriod * MT_CpuFreq;
        MT_uCCycleSafeGuard = (MT_PrecisionTicks * MT_PrescalerDivisor) ;   // Maximum value for "MT_uCCycleSafeGuard" that is compatible with "MT_PrescalerPrecision" and "MT_PrescalerDivisor".
        return -4; // The range of PIH periods scheduled are too wide. You may try to lower "MT_PrescalerPrecision" value (if it is not an issue to your application or, at least, to the smallers PIH period scheduled).
    }

    return 0;
}

int8_t MT_SetClockSource(void) {
// This function uses "MT_PrescalerDivisor" (which values has to be previously determined
// by function "MT_SelectPrescalerDivisor()" ) to configure the ATmega328P's
// Timer/Counter1 Prescaler and store the period value of its ticks to "MT_Timer1Period" .


    uint8_t idx;
    uint8_t aux, aux2;  // This variable data type must be the same as the register in which prescaler divisor value is configured ("TCCR1B")
    unsigned char sreg;
    MT_interval_type auxMin, auxMax;

    /*---- IMPORTANT: this part of this routine may be exclusive to ATmega 328P hardware. ----*/
    //           if your Arduino board has another processor, this routine may require some adjustments. Change lines with TCCR1B register.

    if (MT_PrescalerDivisor == 0) return -1; // Function "MT_SetPrescalerDivisor" must run before a call to "MT_SetCTCmode".

    for (idx=0; idx < MT_PrescalerNumb; idx++) {
        if (MT_PrescalerDivVal[idx] == MT_PrescalerDivisor) break;
    }
    if (idx >= MT_PrescalerNumb) return -2;

    MT_Timer1Period = ((float)MT_PrescalerDivVal[idx]) / ((float)MT_CpuFreq);
    MT_Timer1Period *= 1000000.0;    // Convert period in seconds to period in microseconds;

    MT_minInterval = MT_Timer1Period * ((float)1000 / MT_PrescalerPrecision ); // The MT_minInterval is adjusted to the Timer/Counter1 Prescaler configuration and its value is converted to microseconds.
    MT_maxInterval = MT_Timer1Period * ((uint16_t)(~0x0L)); // The MT_maxInterval is adjusted to the Timer/Counter1 Prescaler configuration and its value is converted to microseconds.

    /* Set bits CS12, CS11 and CS10 in TCCR1B register according to MT_Timer1Period. */
    aux  = ( MT_PrescalerCS1Val[idx] & MT_PrescalerCS1Msk );
    aux2 = ~MT_PrescalerCS1Msk;
    sreg = SREG; // Save global interrupt flag
    cli();
    TCCR1B &= aux2;   // Clear bits CS12, CS11 and CS10 that defines the Timer/Counter 1 prescaler divisor value.
    TCCR1B |= aux;    // Set  CS12, CS11 and CS10 bits that are necessary to define prescaler divisor value as MT_PrescalerDivisor value.
    SREG = sreg; // Restore global interrupt flag .
//    _SEI();

    return 0;
}

bool MT_PrepareOCR(void) {
    MT_repeat_type k = 0;
    MT_ticks_type  schdl_trg_ticks ;
    MT_ticks_type  auxticks = (MT_ticks_type)(~0x0);

    if (MT_timersRunning == 0) return false;   // This function only can be call, when one or more SCHEDULES are included .

    while(k < MT_timersRunning) {  // Select the lowest value of all "MT_schedule[k].periodticks" .
        schdl_trg_ticks = MT_schedule[k].triggerticks;
        if (auxticks > schdl_trg_ticks) auxticks = schdl_trg_ticks;
        ++k;
    }

    MT_OCR1AWrite( auxticks );   // Load the lowest value of all "MT_schedule[k].periodticks" into OCR1A.
    MT_TCNT1Write( 0x0 );        // Clear TCNT1 to reset the count.
    return true;
}

bool MT_StartMultiTimer(void) {
    if (MT_timersRunning > 0)  {
        unsigned char sreg;
        sreg = SREG; // Save global interrupt flag
        cli();   // Disable interrupts
        PRR   &= ~(1 << PRTIM1); // Enable Timer/Counter1 module in Power Reduction Register PRR by clearing respective bit.
        TIMSK1 |= (1 << OCIE1A) | (1 << TOIE1);
        SREG = sreg;
        return true;
    }
    return false;
}

void MT_StopMultiTimer(void) {
    unsigned char sreg;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    TIMSK1 &= ~((1 << OCIE1A) | (1 << TOIE1));
    PRR   |= (1 << PRTIM1); // Disable Timer/Counter1 module in Power Reduction Register PRR  by setting respective bit.
                            //     The Power Reduction Register (PRR), provides a method to stop the clock to individual
                            //      peripherals to reduce power consumption. The current state of the peripheral is
                            //      frozen and the I/O registers can not be read or written.
    SREG = sreg;
}


unsigned int MT_TCNT1Read( void ) {
    unsigned char sreg;
    unsigned int i;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    i = TCNT1; // Read TCNT1 into "i".
    SREG = sreg; // Restore global interrupt flag .
    return i;
}

void MT_TCNT1Write( unsigned int i) {
    unsigned char sreg;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    TCNT1 = i; // Write "i" value into TCNT1.
    SREG = sreg; // Restore global interrupt flag .
}

unsigned int MT_OCR1ARead( void ) {
    unsigned char sreg;
    unsigned int i;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    i = OCR1A; // Read OCR1A into "i".
    SREG = sreg; // Restore global interrupt flag .
    return i;
}

void MT_OCR1AWrite( unsigned int i ) {
    unsigned char sreg;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    OCR1A = i; // Write "i" value into OCR1A.
    SREG = sreg; // Restore global interrupt flag .
}

unsigned int MT_OCR1BRead( void ) {
    unsigned char sreg;
    unsigned int i;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    i = OCR1B; // Read OCR1B into "i".
    SREG = sreg; // Restore global interrupt flag .
    return i;
}

void MT_OCR1BWrite( unsigned int i ) {
    unsigned char sreg;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    OCR1B = i; // Write "i" value into OCR1B.
    SREG = sreg; // Restore global interrupt flag .
}

unsigned int MT_ICR1Read( void ) {
    unsigned char sreg;
    unsigned int i = 0X0;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    i = ICR1; // Read ICR1 into "i".
    SREG = sreg; // Restore global interrupt flag .
    return i;
}

void MT_ICR1Write( unsigned int i ) {
    unsigned char sreg;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    ICR1 = i; // Write "i" value into ICR1.
    SREG = sreg; // Restore global interrupt flag .
}

MT_id_type MT_id_dispatcher = 0;  // This is a flag used to define the ID of all SCHEDULEs.

int8_t MT_IncludeSchedule( MT_interval_type interval, void (*PseudoInterruptHandler)(),
                         uint8_t countdown, MT_id_type *PIH_id,
                         MT_interval_type offset, MT_id_type ofstID) {

// This function include another PIH to the schedule of Timer/Counter1. It also may
// return an ID for the scheduled PIH, which will allow others PIH be synchronized
// and with a different 'phase' with the one identified.


    uint8_t sreg = SREG;


    if (MT_PrescalerDivisor != 0) return -1;
    if (MT_id_dispatcher == ((MT_id_type)(~0x00)) ) return -2; // Too many PIH were scheduled. Consider write another library if you need schedule so many PIH.

    if (countdown == 0x0) countdown = (MT_repeat_type)(~0x00);

    cli();
    if (MT_timersRunning >= MT_scheduleslimit) return -3;

    MT_schedule[MT_timersRunning].id = (++MT_id_dispatcher);    //  The ID number never is "0" value, but can be TOP (0xFF for 8 bits variable).
    MT_schedule[MT_timersRunning].period = interval;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
    MT_schedule[MT_timersRunning].pih_func_ptr = PseudoInterruptHandler;
    MT_schedule[MT_timersRunning].repeat = countdown;
    MT_schedule[MT_timersRunning].offsetinterval = offset;
    MT_schedule[MT_timersRunning].offsetid = ofstID;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
    if (PIH_id != 0) *PIH_id = MT_id_dispatcher;
    MT_schedule[MT_timersRunning].counter = countdown;

    ++MT_timersRunning;

    SREG = sreg;

    return 0;
};

int8_t MT_SetSchedulesTicks(MT_id_type *PIH_id) {
// This function converts the 'period' defined in microseconds for a PIH in the
// corresponding number of ticks that Timer/Counter1 Prescaler elapses in this
// period.
// If  no ID address is passed as argument, all scheduled PIH period will be
// converted. Otherwise, only period of the PIH pointed by "PIH_id" will.


    uint8_t schdl0, schdl1;    // Those variables' data type must be the same as "MT_scheduleslimit".    ---"MT_PrescalerNumb".
    MT_ticks_type intervaltick;


    uint8_t sreg = SREG;
    cli();

    // Select the range of schedules that will be processed.
    if (PIH_id == 0) { // All scheduled PIH must be processed.
        schdl0 = 0;
        schdl1 = MT_timersRunning;
    } else {    // Only a single scheduled PIH  must be processed.
        uint8_t aux = 0;
        while ( (aux < MT_timersRunning ) && (MT_schedule[aux].id != *PIH_id)) {++aux;};
        if (aux >= MT_timersRunning) return -1;
        schdl0 = aux;
        schdl1 = schdl0 + 1;
    }

    // Process schedules
    for(; schdl0 < schdl1; ++schdl0)  {
        intervaltick = MT_schedule[schdl0].period / MT_Timer1Period;
        if (intervaltick == 0) return (-2 -schdl0);
        if (intervaltick <= MT_TicksSafeGuard) return (-3 -schdl0);
        MT_schedule[schdl0].periodticks = intervaltick;
        MT_schedule[schdl0].triggerticks = intervaltick;
    }
    SREG = sreg;

    return 0;
}

int8_t MT_AlignSchedules(MT_id_type *PIH_id, uint8_t absolutedelay) {
// This function adds a delay to shift the next moment the a PIH will be called, but does
// NOT change its period. This may be required if a PIH must be synchronized with another
// but they must have a different phase. Those PIH will have the same frequency/period
// (since programmer supply correct values for their "period" parameter) but they will
// NOT run at the same time.
//
// If  no ID address is passed as argument, all scheduled PIH period will be
// converted. Otherwise, only period of the PIH pointed by "PIH_id" will.

    uint8_t schdl0, schdl1, aux;    // Those variables' data type must be the same as "MT_scheduleslimit".
    MT_id_type auxid;
    MT_ticks_type offsetticks, auxticks;

    uint8_t reg = SREG;
    cli();

    // Select the range of schedules that will be processed.
    if (PIH_id == 0) { // All scheduled PIH must be processed.
        schdl0 = 0;
        schdl1 = MT_timersRunning;
    } else {    // Only a single scheduled PIH  must be processed.
        aux = 0;
        while ( (aux < MT_timersRunning ) && (MT_schedule[aux].id != *PIH_id)) {++aux;};
        if (aux >= MT_timersRunning) return -1;
        schdl0 = aux;
        schdl1 = schdl0 + 1;
    }

    // Process schedules
    for(; schdl0 < schdl1; ++schdl0)  {
        auxid = MT_schedule[schdl0].offsetid;
        if (auxid == MT_schedule[schdl0].id) return -2;  // A SCHEDULE canNOT have an offset delay of itself.

        if (auxid != ~(0U) ) {  //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO reference SCHEDULE to add an OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
            offsetticks = MT_schedule[schdl0].offsetinterval / MT_Timer1Period;
            aux = 0;
            // Find index of the scheduled PIH with "id" parameter value equals to auxid.
            while ( (aux < MT_timersRunning ) && (MT_schedule[aux].id != auxid)) {++aux;};
            if (aux >= MT_timersRunning) return -3;

            if (!absolutedelay) {
                //-- For synchronized PIH's (or PIHs which period are multiple of each other) that canNOT be delayed more than their smallest periodticks.
                //--    If actual PIH 'offsetticks' (MT_schedule[schdl0].periodticks) is greater or equal to the period of PIH scheduled with id equals to actual 'offsetid' ((MT_schedule[aux].periodticks), redefine the actual PIH 'offsetinterval' .
                auxticks = MT_schedule[aux].periodticks;
                if (offsetticks >= auxticks) offsetticks %= auxticks;

                //--    When MT_schedule[aux].periodticks) is a multiple of actual PIH (MT_schedule[schdl0].periodticks) ,
                //--    then if actual 'offsetinterval'(MT_schedule[schdl0].offsetinterval) is greater or equal to the actual PIH 'period' (MT_schedule[schdl0].periodticks), redefine the actual PIH 'offsetinterval' .
                auxticks = MT_schedule[schdl0].periodticks;
                if (offsetticks >= auxticks) offsetticks %= auxticks;
            } else {
              if (  ((MT_ticks_type)(~0x0))-MT_schedule[schdl0].triggerticks < offsetticks  )
                return -4;  // The delay that would be created adding "offsetticks" to "triggerticks" would be greater than
                            //    "triggerticks" data type (same as Timer/Counter1 registers TCNT1 or OCR1A) can hold.
                            //    If the absolute delay must be greater than Timer/Counter1 registers TCNT1 or OCR1A, change
                            //    the data type of "triggerticks" item in struct "MTlog".
            }

            // Introduce a delay to the first call of the actual PIH function ("*pih_func_ptr").
            MT_schedule[schdl0].triggerticks += offsetticks;
        }
    }

    SREG = reg;

    return 0;
};

int8_t MT_ExcludeSchedule(MT_id_type exID){
// This function excludes selected SCHEDULE, even if its counter is not zero.


    MT_id_type aux, aux2;
    uint8_t reg = SREG;
    cli();

    if (MT_timersRunning) {
        aux2 = MT_timersRunning - 1;
    } else {
        return -1; // there is no scheduled PIH. Then, nothing can be excluded.
    };

    for(aux = 0;(aux < MT_timersRunning) && (MT_schedule[aux].id != exID); ++aux);
    if (aux >= MT_timersRunning) return -2;   // ID value in "exID" does NOT match with any PIH id.


    if (aux != aux2){
            // Move the last scheduled PIH to the position of the excluded PIH.
        MT_schedule[aux].id = MT_schedule[aux2].id ;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
        MT_schedule[aux].period = MT_schedule[aux2].period;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
        MT_schedule[aux].repeat = MT_schedule[aux2].repeat;
        MT_schedule[aux].pih_func_ptr = MT_schedule[aux2].pih_func_ptr;
        MT_schedule[aux].offsetinterval = MT_schedule[aux2].offsetinterval;
        MT_schedule[aux].offsetid = MT_schedule[aux2].offsetid;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
        MT_schedule[aux].periodticks = MT_schedule[aux2].periodticks;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
        MT_schedule[aux].triggerticks = MT_schedule[aux2].triggerticks;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
        MT_schedule[aux].counter = MT_schedule[aux2].counter;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
        MT_schedule[aux2].counter = 0;
    }

    MT_timersRunning = aux2;   // Decrease MT_timersRunning;
    SREG = reg;

    if (MT_timersRunning == 0)  MT_StopMultiTimer();


    return 0;
};

int8_t MT_ExcludeCounterZero(void){
// This function excludes all data from a scheduled PIH and also

    MT_id_type aux, aux2;  // Index of the elements in "MT_schedule[]" array.
    uint8_t reg;
    reg = SREG;
    cli();

    if (MT_timersRunning) {
        aux2 = MT_timersRunning - 1;; // Index of the last element in "MT_schedule[]" array.

        for(aux = 0; aux <= aux2; ++aux, --aux2) {
            while ((MT_schedule[aux].counter > 0 )  && (aux < aux2) ) {++aux;}
            while ((MT_schedule[aux2].counter == 0) && (aux < aux2)  ) {--aux2;}
            if (aux != aux2){
                    //--- Move the last scheduled PIH to the position of the excluded PIH.
                MT_schedule[aux].id = MT_schedule[aux2].id ;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
                MT_schedule[aux].period = MT_schedule[aux2].period;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
                MT_schedule[aux].repeat = MT_schedule[aux2].repeat;
                MT_schedule[aux].pih_func_ptr = MT_schedule[aux2].pih_func_ptr;
                MT_schedule[aux].offsetinterval = MT_schedule[aux2].offsetinterval;
                MT_schedule[aux].offsetid = MT_schedule[aux2].offsetid;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
                MT_schedule[aux].periodticks = MT_schedule[aux2].periodticks;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
                MT_schedule[aux].triggerticks = MT_schedule[aux2].triggerticks;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
                MT_schedule[aux].counter = MT_schedule[aux2].counter;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".

#if defined(_SAFEGUARDCHECK_) & (!defined(_SAFEGUARDCHECK_Plus_))
Serial.print("\n  >>  Excluded "); Serial.println(aux);
#endif //

            } else if (MT_schedule[aux].counter == 0) {

#if defined(_SAFEGUARDCHECK_) & (!defined(_SAFEGUARDCHECK_Plus_))
Serial.print("\n  >>  Excluded "); Serial.println(aux);
#endif //

                break;   // Avoid "aux" to be incremented by the "for" loop statement.
            }
        }
        MT_timersRunning = aux;
    }

    SREG = reg;
    MT_schedulefinished = false;
    if (MT_timersRunning == 0)  MT_StopMultiTimer();

    return 0;
};

int8_t MT_ScheduleCounterDec(MT_id_type Sched_id, MT_repeat_type val) {
    uint8_t schdl;         // This variable's data type must be the same as "MT_scheduleslimit".
    MT_repeat_type aux;    // The data type of this variable must be the same as "MT_timersRunning".
    uint8_t reg = SREG;
    int8_t ret = 0;

    if (val == 0) return 0;
    schdl = 0;

    cli();
    //--- Find the schedule with "id" equals to "Sched_id" argument.
    while ( (schdl < MT_timersRunning ) && (MT_schedule[schdl].id != Sched_id)) {++schdl;}
    if (schdl >= MT_timersRunning) return -1;  // No scheduled PIH has its "id" parameter with a value equal to "Sched_id" argument.

    //--- Decrease the counter of the schedule.
    aux = MT_schedule[schdl].counter;
    if ( aux != (MT_repeat_type)(~0x00) ) {
        if (aux > val) {
            MT_schedule[schdl].counter = aux - val;
        } else {
            MT_schedule[schdl].counter = 0;
            MT_schedulefinished = true;  // MT_ScheduleCounterDec() function is called inside "MT_ExecSchedulesPIH()", but
                                         //     "MT_schedule[]" can NOT be changed until "MT_ExecSchedulesPIH()" returns.
                                         //     Because of this, "MT_schedulefinished" is used to inform "ISR(TIMER1_COMPA_vect)"
                                         //     that exist SCHEDULEs that must be excluded.
            ret = 1;   //  This return value represents that this function excluded the scheduled PIH.

#if defined(_SAFEGUARDCHECK_) & (!defined(_SAFEGUARDCHECK_Plus_))
Serial.print("\n  >>  Finished "); Serial.print(schdl);
#endif //
        }
    }

    SREG = reg;

    return ret;
}

int MT_ExecSchedulesPIH() {
//
//  "MT_ActualTriggerTicks" can be considered the time interval that must be elapsed between the last call of a
//  scheduled PIH function and the next call to a scheduled PIH function, but measured in Timer/Counter1
//  Prescaler output ticks ("clk_T1").
//  At the start/end of each CYCLE of Timer/Counter1 ISR (FOR loop), any scheduled PIH may be in one of four conditions:
//   * a)  the schedule's "triggerticks" parameter indicates that the next time it's PIH must be called is greater
//         than "MT_ActualTriggerTicks" ;
//   * b)  the schedule's "triggerticks" parameter indicates that the next time it's PIH must be called is equal
//         to "MT_ActualTriggerTicks" ;
//   * c)  the schedule's "triggerticks" parameter indicates that the time when it's PIH should be called is 'slightly'
//         smaller than "MT_ActualTriggerTicks" and this difference is small when compared to the schedule's "periodticks";
//         i.e. the call to this schedule's PIH is late but the time to call this PIH  for the second time has NOT came yet;
//   * d)  the schedule's "triggerticks" parameter indicates that the time when it's PIH should be called is 'much'
//         smaller than "MT_ActualTriggerTicks" and this difference is big when compared to the schedule's "periodticks"; i.e.
//         the call to this schedule's PIH is so late that two or more calls to it has elapsed without the PIH had been executed;
//
// This four conditions may be represented by follow time line graphics:
//     (LC = last call to Timer/Counter1 OCR1A ISR;  NC = next call to Timer/Counter1 OCR1A ISR)
//         LC                             NC
//         | - - - - - - - - - - - - - - - |
//   a)    | - - - - - - - - - - - - - - - - - - ... - - x
//   b)    | - - - - - - - - - - - - - - - x
//   c)    | - - - - - - - x . . . . . . . .     (triggerticks not close tho LC neither NC (end of MT_ActualTriggerTicks))
//                          [==============================]  periodticks
//   d)    | - - - - - - - x . . . . . . . .     (triggerticks not close tho LC neither NC (end of MT_ActualTriggerTicks))
//                 [=====][=====][=====][=====]  periodticks
//
//  The condition "b)" and "d)" may be subdivided by relative position of the end of its schedule's
//  "periodticks" increments to the end of "MT_ActualTriggerTicks":
//         LC                             NC
//         | - - - - - - - - - - - - - - - |
//   b.1)  | - - - - - - - - - - - - - - - - x    (end of MT_ActualTriggerTicks happens a little before end of triggerticks)
//   b.2)  | - - - - - - - - - - - - - - - x      (end of MT_ActualTriggerTicks happens at the same time than end of triggerticks )
//   b.3)  | - - - - - - - - - - - - - - x .      (end of MT_ActualTriggerTicks happens a little after end of triggerticks)
//
//         LC                             NC
//         | - - - - - - - - - - - - - - - |
//   d.1)  | - - - - - - - x . . . . . . . .     (the end/beginning of a multiple periodticks sequence do NOT coincides closer to NC (end of MT_ActualTriggerTicks))
//                 [=====][=====][=====][=====]  periodticks
//   d.2)  | - - - - - - - - - x . . . . . .     (the end/beginning of a multiple periodticks sequence coincides closer to NC (end of MT_ActualTriggerTicks))
//                     [=====][=====][=====]     periodticks

    MT_ticks_type  MT_ActualTriggerTicks;  // The time interval, measured in prescaler ticks, required to call the actual (first) PIH.
    bool PIH_exected;      // Flag used to indicate that at least one PIH was called in the same Timer/Counter1 ISR call in a FOR loop.
    MT_repeat_type aux;    // The data type of this variable must be the same as "MT_timersRunning".
    MT_ticks_type auxticks, auxticksdiff, auxperiodticks;
    MT_ticks_type auxNextTriggerTicks;  // The time interval, measured in prescaler ticks, required to call the "next" (first) PIH.
    uint16_t tcnt;       // A variable to hold the value of the Timer/Counter1 TCNT1 register.

    MT_ActualTriggerTicks = MT_OCR1ARead();
    //--- Avoid another interrupt be started before finish this one.
    MT_OCR1AWrite(0XffffU);  // This will be enough only if TCNT1 is automatically reset when it reaches OCR1A value.

    //--- Apply changes required for new scheduled PIH (that may need a different Prescaler configuration or not).
    //  Future improvements code space ...

    //--- Search for the next PIH to be triggered (immediately)
    do {
        PIH_exected = false;
        auxNextTriggerTicks = (MT_ticks_type)(~0x0);

        //--- Check all "MT_schedule[]" to execute PIH functions from those which "MT_schedule[].triggerticks" is approximately equal to or less than "MT_ActualTriggerTicks".
        //    Update all "MT_schedule[].triggerticks" to the next call o fits PIH.
        for (uint8_t k=0; k < MT_timersRunning; ++k) {
            auxticks = MT_schedule[k].triggerticks;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("\n\t...Schedule "); Serial.print(k);
Serial.print("; triggerticks "); Serial.print(auxticks);
Serial.print("; MT_ActualTriggerTicks "); Serial.print(MT_ActualTriggerTicks);
Serial.print("; TCNT1 "); Serial.print(MT_TCNT1Read());
#endif // defined

            if (auxticks > (MT_ActualTriggerTicks + MT_TicksSafeGuard)) {  // Schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "a)".
                MT_schedule[k].triggerticks = auxticks - MT_ActualTriggerTicks;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case A");
#endif // defined

            } else {
                MT_repeat_type auxcounterdecr;
                auxperiodticks = MT_schedule[k].periodticks;
                if (auxticks >= (MT_ActualTriggerTicks - MT_TicksSafeGuard)) {  // MT_schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "b)".
                    (*MT_schedule[k].pih_func_ptr)();
                    PIH_exected = true;
                    auxcounterdecr = 1;
                    if (auxticks > MT_ActualTriggerTicks) {  // MT_schedule[k].triggerticks (a little after at the end of a Timer/Counter1 cycle) represents a condition "b.1)".
                        auxticks = (auxticks - MT_ActualTriggerTicks) + auxperiodticks;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case B.1");
#endif // defined

                    } else {  // MT_schedule[k].triggerticks (a little before or at same time than end of a Timer/Counter1 cycle) represents a condition "b.2)" or "b.3)".
                        auxticks = auxperiodticks - (MT_ActualTriggerTicks - auxticks);

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Cases B.2 & B.3");
#endif // defined

                    }
                    MT_schedule[k].triggerticks = auxticks;
                } else {
                    auxticksdiff = MT_ActualTriggerTicks - auxticks;
                    if (auxticksdiff < auxperiodticks) { // MT_schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "c)".
                        auxcounterdecr = 1;
                        ++MT_LostPIHCall;    // Increase the counter of lost PIH call . This counter do not show which PIH has been lost, but the sum of all PIH function call lost.
                        MT_schedule[k].triggerticks = auxperiodticks - auxticksdiff;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case C");
#endif // defined

                    } else {   // MT_schedule[].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "d)".
                        MT_ticks_type auxlost = (auxticksdiff / auxperiodticks) ; // The number of times that PIH should be called (less one unit).
                        MT_ticks_type periodslostinterv = auxperiodticks * auxlost;   // Time (in Timer/Counter1 Prescaler ticks) between first the moment that this PIH should be called and the last moment (more recent or exactly now).
                        auxcounterdecr = auxlost + 1;
                        auxticks =  auxperiodticks * auxcounterdecr - auxticksdiff;
                        bool CallPIH = false;
                        if (periodslostinterv >= (auxticksdiff - MT_TicksSafeGuard)) { // (the end/beginning of a multiple periodticks sequence coincides to NC (end of MT_ActualTriggerTicks) or is happen little before NC)
                            // MT_schedule[k].triggerticks' position relative to "MT_ActualTriggerTicks" represents a condition "d.2)" .
                            CallPIH = true;
                            MT_LostPIHCall += auxlost;
                            auxticks = auxperiodticks - (auxticksdiff - periodslostinterv);

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case D.2.a");
#endif // defined

                        } else if ((periodslostinterv + auxperiodticks) <= (auxticksdiff + MT_TicksSafeGuard)) {  // (the end/beginning of a multiple periodticks sequence happens little after NC (end of MT_ActualTriggerTicks))
                            // MT_schedule[k].triggerticks' position relative to "MT_ActualTriggerTicks" represents a condition "d.2)" .
                            CallPIH = true;
                            MT_LostPIHCall += auxcounterdecr;
                            ++auxcounterdecr;
                            auxticks =  ((periodslostinterv + auxperiodticks) - auxticksdiff) + auxperiodticks;
                        //--- Future improvements:
                        //    } else if (MT_CallLatePIH == true) {   //  Need to create new flag "MT_CallLatePIH", to indicate that a late PIH must be called any way.
                        //        CallPIH = true;
                        //        MT_LostPIHCall += auxcounterdecr;
                        //    }

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case D.2.b");
#endif // defined

                        } else {
                            // MT_schedule[k].triggerticks' position relative to "MT_ActualTriggerTicks" represents a condition "d.1)" .
                            MT_LostPIHCall += auxcounterdecr;
                            auxticks = auxperiodticks - (auxticksdiff - periodslostinterv);

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Case D.1");
#endif // defined

                        }
                        if (CallPIH && (MT_schedule[k].counter > auxcounterdecr) ){
                            (*MT_schedule[k].pih_func_ptr)();
                            PIH_exected = true;
                            MT_schedule[k].triggerticks = auxticks;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; late PIH called");
#endif // defined

                        }

                    }  // if (auxticksdiff < auxperiodticks) { // MT_schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "c)".
                }  // if (auxticks >= (MT_ActualTriggerTicks - MT_TicksSafeGuard)) {  // MT_schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "b)".
                MT_ScheduleCounterDec(MT_schedule[k].id, auxcounterdecr);
            }  //  if (auxticks > (MT_ActualTriggerTicks + MT_TicksSafeGuard)) {  // Schedule[k].triggerticks (at the end of a Timer/Counter1 cycle) represents a condition "a)".

            //--- Find the next value of MT_ActualTriggerTicks for the next FOR loop.
            auxticks = MT_schedule[k].triggerticks;
            if (auxticks < auxNextTriggerTicks ) auxNextTriggerTicks = auxticks;

#if defined(_SAFEGUARDCHECK_Plus_)
    Serial.print("\n\t\t new triggerticks "); Serial.print(MT_schedule[k].triggerticks);
    Serial.print("; auxNextTriggerTicks "); Serial.print(auxNextTriggerTicks);
    Serial.print("; TCNT1 "); Serial.print(MT_TCNT1Read());
    Serial.print("; counter "); Serial.print(MT_schedule[k].counter);
#endif // defined

        }  // for (uint8_t k=0; k < MT_timersRunning; ++k)

        //--- Update "MT_ActualTriggerTicks" value and enforce a new
        tcnt = MT_TCNT1Read();
        if (auxNextTriggerTicks <= (tcnt + MT_TicksSafeGuard)) {

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; Long ISR runtime");
#endif // defined

            PIH_exected = true;  // Enforce a re-entry in "for (uint8_t k=0; k < MT_timersRunning; ++k)" loop.
        }
        if (PIH_exected) {
            MT_ActualTriggerTicks = MT_TCNT1Read();
            MT_TCNT1Write(0u); // Reset Timer/Counter1 TCNT1 register to restart MT_schedule checkup: "for (uint8_t k=0; k < MT_timersRunning; ++k)" loop.

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; repeat");
#endif // defined

        } else {
            MT_ActualTriggerTicks = auxNextTriggerTicks;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("; END");
#endif // defined

        }

    } while (PIH_exected);   // Keeps the Timer/Counter1 ISR repeating the "for" statement until no SCHEDULE trigger its PIH.

    //--- Load "MT_ActualTriggerTicks" into OCR1A.
    MT_OCR1AWrite( MT_ActualTriggerTicks );

};


int8_t MT_NewSchedule( MT_interval_type interval, void (*PseudoInterruptHandler)(),
                         uint8_t countdown, MT_id_type *PIH_id,
                         MT_interval_type offset, MT_id_type ofstID,
                         uint8_t absolutedelay) {

// This function include another PIH to the schedule of Timer/Counter1. It also may
// return an ID for the scheduled PIH, which will allow others PIH be synchronized
// and with a different 'phase' with the one identified.

    uint16_t trigger_interval, tcnt1;
    MT_ticks_type intervaltick, auxtrigger;
    uint8_t sreg = SREG;
    uint8_t aux;    // This variable's data type must be the same as "MT_scheduleslimit".
    MT_ticks_type offsetticks, auxticks;

    if (MT_PrescalerDivisor == 0) return -1;

    cli();
    if (MT_schedulefinished) MT_ExcludeCounterZero();
    if (MT_timersRunning >= MT_scheduleslimit) return -2;
    if (MT_id_dispatcher == ((MT_id_type)(~0x00)) ) return -3; // Too many PIH were scheduled. Consider write another library if you need schedule so many PIH.
    if (interval < MT_minInterval) return -4;  // Any SCHEDULE which period is smaller than "MT_minInterval" may require STOP and RECONFIGURE MultiTimer.
    if (interval > MT_maxInterval) return -5;  // Any SCHEDULE which period is greater than "MT_maxInterval" may require STOP and RECONFIGURE MultiTimer.

    if (PRR & (1 << PRTIM1)) {
        PRR   &= ~(1 << PRTIM1); // Enable Timer/Counter1 module in Power Reduction Register PRR by clearing respective bit.
        TIMSK1 |= (1 << OCIE1A) | (1 << TOIE1);

#if defined(_SAFEGUARDCHECK_)
Serial.print("\n  >>  MT_Start, PRR "); Serial.println(PRR, BIN);
#endif //

    }

    if (countdown == 0x0) countdown = (MT_repeat_type)(~0x00);

    MT_schedule[MT_timersRunning].id = (++MT_id_dispatcher);    //  Period of the time interval in which this PIH must be called, measured in microseconds.
    MT_schedule[MT_timersRunning].period = interval;    //  Period of the time interval in which this PIH must be called, measured in microseconds.
    MT_schedule[MT_timersRunning].pih_func_ptr = PseudoInterruptHandler;
    MT_schedule[MT_timersRunning].repeat = countdown;
    MT_schedule[MT_timersRunning].offsetinterval = offset;
    MT_schedule[MT_timersRunning].offsetid = ofstID;    //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
    if (PIH_id != 0) *PIH_id = MT_id_dispatcher;
    MT_schedule[MT_timersRunning].counter = countdown;

    //--- Set Schedules' Ticks parameters.
    intervaltick = interval / MT_Timer1Period;
    MT_schedule[MT_timersRunning].periodticks = intervaltick;
    MT_schedule[MT_timersRunning].triggerticks = intervaltick;

    //--- Align (synchronize)  the this SCHEDULE period with period of another SCHEDULE
    if (ofstID != ~(0U) ) {  //  Flag value "~(0U)"  (maximum value of MT_id_type data type) means NO reference SCHEDULE to add an OFFSET, i.e., do not delay to the first call of "*pih_func_ptr".
        if (MT_id_dispatcher == ofstID) return (-6);  // A SCHEDULE canNOT have an offset delay of itself.
        MT_ticks_type offsetticks = offset / MT_Timer1Period;
        // Find index of the scheduled PIH with "id" parameter value equals to ofstID.
        aux = 0;
        while ( (aux < MT_timersRunning ) && (MT_schedule[aux].id != ofstID)) {++aux;};
        if (aux >= MT_timersRunning) return -7;

        if (!absolutedelay) {
            //-- For synchronized PIH's (or PIHs which period are multiple of each other) that canNOT be delayed more than their smallest periodticks.
            //--    If this new included PIH 'offsetticks' is greater or equal to the period of PIH scheduled with id equals to actual 'ofstID' ((MT_schedule[aux].periodticks), redefine the actual PIH 'offsetinterval' .
            auxticks = MT_schedule[aux].periodticks;
            if (offsetticks >= auxticks) offsetticks %= auxticks;

            //--    When MT_schedule[aux].periodticks) is a multiple of this new  included PIH 'periodticks' ,
            //--    then if this new included PIH 'offset' is greater or equal to the actual PIH 'periodticks' , redefine the actual PIH 'offset' .
            if (offsetticks >= intervaltick) offsetticks %= intervaltick;
        } else {
//              if (  ((MT_ticks_type)(~0x0))-offsetticks < MT_schedule[schdl0].triggerticks )
          if (  ((MT_ticks_type)(~0x0))- intervaltick < offsetticks  )
            return -8;  // The delay that would be created adding "offsetticks" to "triggerticks" would be greater than
                        //    "triggerticks" data type (same as Timer/Counter1 registers TCNT1 or OCR1A) can hold.
                        //    If the absolute delay must be greater than Timer/Counter1 registers TCNT1 or OCR1A, change
                        //    the data type of "triggerticks" item in struct "MTlog".
        }

        // Introduce a delay to the first call of the actual PIH function ("*pih_func_ptr").
        MT_schedule[MT_timersRunning].triggerticks += offsetticks;
    }

    ++MT_timersRunning;

    SREG = sreg;

    auxtrigger = MT_schedule[MT_timersRunning - 1].triggerticks;
    trigger_interval  = MT_OCR1ARead();
    tcnt1 = MT_TCNT1Read();
    trigger_interval -= tcnt1;  // Lasting Prescaler output ticks before next call to "ISR(TIMER1_COMPA_vect)".

    //-- Check if this SCHEDULE PIH must be called before any other SCHEDULE.
    if ( trigger_interval > ( auxtrigger + MT_TicksSafeGuard) ) {
        MT_OCR1AWrite(auxtrigger + tcnt1); // Update (decrease) the time interval to call "ISR(TIMER1_COMPA_vect)", because the new SCHEDULE PIH must be called before any other SCHEDULE.
    }
    MT_schedule[MT_timersRunning - 1].triggerticks += tcnt1; // Adapt the time that this new SCHEDULE PIH must be called to the running TCNT1 values.

    return 0;
}


#if defined( _SAFEGUARDCHECK_ )
bool Startup_Error = false;   //  This flag is set if initial setup of any Timer/Counter 0 or 1 fail.

// Timer/Counter2 is used to count microcontroller clock cycles. But instead of using only TCNT2 (timer/counter register)
// this "helper/debugger" application generates a software register (variable "T2_MSB") able to increase the total
// significant bits of the timer/counter.
typedef uint8_t Counter_Hw_type;   // Unsigned Integer type for TCNT2 ( timer/counter register). Data type of Hardware register, the Least significant bits of GLOBAL (hardware+software) TIMER/COUNTER register.
typedef uint32_t Counter_Sw_type;  // Unsigned Integer type for TCNT2 ( timer/counter register). Data type of Software ("T2_MSB") register, the Most significant bits of GLOBAL (hardware+software) TIMER/COUNTER register.

Counter_Sw_type volatile T2_MSB = 0;   // Counts how many times Timer/Counter2 had overflown and acts like TCNT2 Most Significant Word.
uint16_t volatile PIH_call = 0;     // Count the number of times that any SCHEDULE called its PIH.
uint16_t volatile T1_ISRcall = 0;   // Counts how many times "ISR(TIMER1_COMPA_vect)" has been called.
Counter_Sw_type volatile T1_ISR_ClockPulses = 0;   // Accumulates the total of clock pulses during all times that "ISR(TIMER1_COMPA_vect)" was executes.

#if defined(_SAFEGUARDCHECK_Plus_)
unsigned long BaseInterval = 1248000UL;   // Interval for all schedules used in MT_SafeGuardCheck(). Values are in micro seconds
uint8_t PIHrepetition = 20;          // Number of times that all schedules will call its PIH. Do NOT use "0xFF" neither "0x0", because all schedules will run indefinitely.
#else
unsigned long BaseInterval = 752000UL;   // Interval for all schedules used in MT_SafeGuardCheck(). Values are in micro seconds
uint8_t PIHrepetition = 0xFE;          // Number of times that all schedules will call its PIH. Do NOT use "0xFF" neither "0x0", because all schedules will run indefinitely.
#endif // defined

void PIH_SafeGuardCheck(void);

ISR(TIMER2_OVF_vect){
    // Timer/Counter2 shall be configured to count the CPU clock cycles, without prescaling.
    ++T2_MSB;
}

unsigned char MT_TCNT2Read( void ) {
    unsigned char sreg;
    unsigned char i;
    sreg = SREG; // Save global interrupt flag
    cli();   // Disable interrupts
    i = TCNT2; // Read TCNT2 into "i".
    SREG = sreg; // Restore global interrupt flag .
    return i;
}

int8_t MultiVariableCounter_Difference( Counter_Sw_type msb_1, Counter_Hw_type tcnt_1,
                                        Counter_Sw_type msb_0, Counter_Hw_type tcnt_0, Counter_Sw_type *delta) {
//   This function calculates the difference (or time interval) between two Timer/Counter values, that are
//   stored in hardware register and auxiliary software register (variable updated in an Interrupt Service
//   Routine). The parameters that receive values read in the first moment are "msb_0" (software register
//   with Most significant bits) and "tcnt_0" (hardware register with Least significant bits). The parameters
//   that receive values read in a moment after are "msb_1" (software register with Most significant bits)
//   and "tcnt_1" (hardware register with Least significant bits).
//
//   IMPORTANT: this function in intended to unsigned variables. All argument values and the variable pointed
//              by "delta" parameter must be defined as UNSIGNED integers.
//              The calculations are able to deal with Global registers (software + hardware) overflow.
//              I.e., suppose that in the first moment that Time/Counter (TIMER2) was read, its hardware
//              register ("TCNT2") had value 0x08 and its software register ("T2_MSB", supposing it has 16
//              bits size) has value 0x0000 . Also, in a second moment, the hardware register has value 0x06
//              and the software register has 0x0000. It means that the Global register overflow, both hardware
//              and software registers reach its top value (0xFF and 0xFFFF, respectively) and then they reset
//              (to 0x00) continue increasing. In this case, the variable pointed by "delta" parameter will
//              receive the time interval value of 0xFFFE.
//              If  Global registers value read in the first moment is equal to the values read in the second
//              moment, the time interval returned to variable pointer by "delta" parameter will be "0x00".

    Counter_Hw_type delta_lsb;
    Counter_Sw_type delta_msb;
    int8_t r = 0;


    //--- Calculate the independent contribution of each part (software and hardware) of the GLOBAL TIMER/COUNTER register.
        //-- Check if software part of GLOBAL TIMER/COUNTER register is up to date.
    if ((tcnt_0 > tcnt_1) && (msb_1 == msb_0)) {

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("\n  >> ERROR: invalid time value."); // This condition should NOT happen. It may be caused by a Global register (hardware + software) overflow.
#endif // defined

        ++msb_1; // A low value in "tcnt_1" may mean that ISR(TIMER2_OVF_vect) did not have enough time to increase "T2_MSB".
                   //     If another ISR is running (with Interrupt flag in SREG disabled), then if the hardware register
                   //     TCNT2 overflow, the ISR(TIMER2_OVF_vect) will only be called after the former ISR return. This
                   //     leads to a situation that TCNT2 hardware register will reset and keep increasing but the software
                   //     register "T2_MSB" will keep its old value until the former ISR return and ISR(TIMER2_OVF_vect) gets
                   //     its turn (when all other triggered ISR with highest priority returns).
                   //     In this case, "(msb_1 == msb_0)" will result in true value, but the real situation is that "msb_1"
                   //     shall be increased by one unit before proceed with any comparison.
                   //     There is also a possibility of GLOBAL register (hardware + software) overflow. To avoid it, the
                   //     capacity of the Global Register may be enough bigger than: maximum interval of any SCHEDULE period
                   //     plus execution time of all SCHEDULEs' PIH. This grants that all SCHEDULEs may be triggered
                   //     simultaneously and GLOBAL register will not overflow.
    }

     // All calculations bellow may be wrongly affected if software register ("T2_MSB") is not update immediately after
     // hardware register "TCNT2" overflow. So, the ISR(TIMER2_OVF_vect) cannot
     // The functions or ISR that reads GLOBAL registers (software and hardware) values must:
     //    *) read hardware register "TCNT2" before read software register "T2_MSB";
     //    *) must avoid any higher priority level Interrupt (compared to ISR(TIMER2_OVF_vect) priority level),
     //       by disabling (masking) all Interrupts (like clearing I flag in Status Register).

        //-- Check if overflow had occurred in GLOBAL (hardware+software) TIMER/COUNTER register.
    if (msb_0 > msb_1) {
        delta_msb = ((((Counter_Sw_type)(~0x0LL)) - msb_0) + msb_1);  // The contribution of Most Significant Bits to the Total Time Interval.
        //  SREG_Carry_bit = bitRead(SREG, SREG_C); // In Arduino's library "commom.h" there are the definitions of "SREG" and "SREG_C" (Carry flag in Status Register).
                                                     //     "#define SREG _SFR_IO8(0x3F) "  and "#define SREG_C  (0)"
    }else {
        delta_msb = msb_1 - msb_0;  // The contribution of Most Significant Bits to the Total Time Interval.
    }
    if (tcnt_0 > tcnt_1) {
        --delta_msb;  // Include the Minus Carry of Least Significant Bits contribution to the Most Significant Bits contribution.
                      // Even if "msb_1" and "msb_0" values are equal to 0x0000, the "delta_msb" must be decreased, turning to 0xFFFF.
        delta_lsb = ((((Counter_Hw_type)(~0x0LL)) - tcnt_0) + tcnt_1 + 1); // The contribution of Least Significant Bits to the Total Time Interval.
    } else {
        delta_lsb = tcnt_1 - tcnt_0; // The contribution of Least Significant Bits to the Total Time Interval.
    }

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print(" :( "); Serial.print(delta_msb); Serial.print(" <<8 + "); Serial.print(delta_lsb); Serial.print(")");
#endif // defined

    //-- Check if the contribution of Most Significant Bits Variable will overflow after a bit shift operation.
    if ( delta_msb > ( ((Counter_Sw_type)(~0x0LL)) >>  (sizeof(Counter_Hw_type) * CHAR_BIT) ) ) {
        r -= 1;   // "delta_msb" value will overflow when bit shift operation will be applied .
        delta_msb = 0;  // The 0x0 value is a flag value when the interval difference between two GLOBAL register
                        //     does NOT fit in a variable of type "Counter_Sw_type".
                        // This could be solved if the size of the variable pointed by "delta" parameter is equal or
                        //    greater than the sum of the sizes of "Counter_Sw_type" and "Counter_Hw_type" types.
    } else {
        //--- Convert the delta values ("delta_msb" and "delta_lsb") from the difference of GLOBAL TIMER/COUNTER
        //    registers (composed of two variables) into a single variable.
        delta_msb = (delta_msb << (sizeof(Counter_Hw_type)*CHAR_BIT) ) | ((Counter_Sw_type)delta_lsb); // Calculates
    }

    //--- Store calculated Time interval in variable pointed by "delta" parameter.
    if (delta != 0x0) *delta = delta_msb;

    return r;
}

ISR(TIMER1_COMPA_vect){
    Counter_Sw_type t2msb_0,  t2msb_1, delta_total;
    Counter_Hw_type t2tcnt_0, t2tcnt_1;

        // Variables t2msb_0,  t2msb_1 are used as 1st and 2nd MOST Significant Byte of CPU Clock Counter.
        // Variables t2tcnt_0, t2tcnt_1 are used as LEAST Significant Byte of CPU Clock Counter.
        // The use of 3 bytes (24 bits) counters allows the "ISR(TIMER1_COMPA_vect)" have a run time lower or equal to one second, in a 16MHz clock, without the Counters variable overflow.
    ++T1_ISRcall;

#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("\n  >> ISR call "); Serial.print(T1_ISRcall);
#endif // defined

    TCNT2 = 0u; // Write "0X0" value into TCNT2.
    T2_MSB = 0;
    t2tcnt_0 = MT_TCNT2Read();
    t2msb_0 = T2_MSB; // T2_MSB must be read before TCNT2 if according to WGMx flags (wave generation flags) TOV2 Flag is set on NAX (TCNT2 == 0xFF) instead of Bottom (TCNT2=0x00).

  //--- Begin of ISR -----
    sei(); // Enable nested interrupts.
    // __asm__ __volatile__ ("nop\n\t");      // In "Arduino.h" library you will find:  " #define _NOP() do { __asm__ volatile ("nop"); } while (0) "
    MT_T1COMPArunning = true;
    // PIH_SafeGuardCheck();
    MT_ExecSchedulesPIH();
    if (MT_schedulefinished) MT_ExcludeCounterZero();
    MT_T1COMPArunning = false;
  //--- End of ISR -----
    cli();
    t2tcnt_1 = MT_TCNT2Read();
    t2msb_1 = T2_MSB;
    sei();

//    MT_OCR1AWrite( MT_schedule[0].periodticks * 4 );   // Force the worst condition (run the greatest code path inside ISR, to assure the greatest runtime)


#if defined(_SAFEGUARDCHECK_Plus_)
Serial.print("\n\tTCNT2_0 "); Serial.print(t2msb_0); Serial.print("<<"); Serial.print (sizeof(t2tcnt_0)*8); Serial.print("+"); Serial.print(t2tcnt_0);
MultiVariableCounter_Difference(t2msb_0, t2tcnt_0, 0, 0, &delta_total);
Serial.print(" = "); Serial.print(delta_total);
Serial.print("\tTCNT2_1 ");   Serial.print(t2msb_1); Serial.print("<<"); Serial.print (sizeof(t2tcnt_1)*8); Serial.print("+"); Serial.print(t2tcnt_1);
MultiVariableCounter_Difference(t2msb_1, t2tcnt_1, 0, 0, &delta_total);
Serial.print(" = "); Serial.print(delta_total);
Serial.print("  * PRINTING included"); // All the time required to execute "Serial.print()" inside "MT_ExecSchedulesPIH();" is included in this result.
#endif // defined


    if (MultiVariableCounter_Difference(t2msb_1, t2tcnt_1, t2msb_0, t2tcnt_0, &delta_total) < 0) {
        Serial.print(" TIMER OVERFLOW");
        --T1_ISRcall;
    } else {
        T1_ISR_ClockPulses += delta_total;
    };

#if !defined(_SAFEGUARDCHECK_Plus_)
Serial.print(T1_ISRcall);    Serial.print("/\t");
#endif
    Serial.print("\n  >> Actual ISR clk "); Serial.print(delta_total);   // Clock Cycles in this actual call to "ISR(TIMER1_COMPA_vect)" (including clock cycles of all call to "PIH_SafeGuardCheck()" ).
    Serial.print("; Total ISR clk "); Serial.print(T1_ISR_ClockPulses);  // Cumulated Clock Cycles in all calls to "ISR(TIMER1_COMPA_vect)" (including clock cycles of all call to "PIH_SafeGuardCheck()" ).
    Serial.print("; Total PIH call "); Serial.println(PIH_call);  // Cumulated number of times that "PIH_SafeGuardCheck()" was called by any SCHEDULEs.


}

#else
ISR(TIMER1_COMPA_vect){
    MT_T1COMPArunning = true;

    sei(); // Enable nested interrupts.

    MT_ExecSchedulesPIH();
    if (MT_schedulefinished) MT_ExcludeCounterZero();
    MT_T1COMPArunning = false;

}
#endif // #if defined( _SAFEGUARDCHECK_ )

ISR(TIMER1_OVF_vect){
    ++MT_Tcnt1Overflow;
}

/** /



//------ CODE TO CALCULATE A REASONABLE VALUE (IN WORST CASE SCENARIO) FOR "MT_uCCycleSafeGuard" ------//
//  This code is used to help in the estimation of the time required to run "ISR(TIMER1_COMPA_vect)".
//  Variable "MT_uCCycleSafeGuard" represents the number of clock cycles within this time.
//  If this time is to much bigger, SCHEDULES with small periods may NOT have enough precision.
//  This time depends on how many SCHEDULEs run simultaneously and the time required to run all SCHEDULE
//  PIH. Once this time is found, the variable "MT_uCCycleSafeGuard" value may be calculated.
//  The minimum value to variable "MT_uCCycleSafeGuard" happens when there is only 2 SCHEDULES, which PIH's are
//  never called at the same "ISR(TIMER1_COMPA_vect)" call. In this case, only the PIH with the greatest run time
//  must be included in "MT_uCCycleSafeGuard"
//  There may be applications where all SCHEDULES are synchronized allowing all PIH be called at the same
//  "ISR(TIMER1_COMPA_vect)" call. In this case, the time required to run all PIH may be included in calculation
//  of "MT_uCCycleSafeGuard" value.
//  Any way, "MT_uCCycleSafeGuard" value depends on the application. But here the time to run "ISR(TIMER1_COMPA_vect)"
//  is calculated without including no PIH run time.

//--- IMPORTANT      ------      IMPORTANT      ------      IMPORTANT      ------      IMPORTANT
//  To run this sample code, directive "#define _SAFEGUARDCHECK_" in file "MultiTimer_ISR.cpp" must be uncommented.
//  After use this sample code, do comment directive "#define _SAFEGUARDCHECK_" in file "MultiTimer_ISR.cpp"

#include <MultiTimer_ISR.h>

extern bool Startup_Error;

extern uint16_t volatile PIH_call;          // Count the number of times that any SCHEDULE called its PIH.
extern uint16_t volatile T1_ISRcall;        // Counts how many times "ISR(TIMER1_COMPA_vect)" has been called.
extern uint32_t volatile T1_ISR_ClockPulses;   // Accumulates the total of clock pulses during all times that "ISR(TIMER1_COMPA_vect)" was executes.
extern unsigned long BaseInterval;          // Interval for all schedules used in MT_SafeGuardCheck(). Values are in micro seconds
extern uint8_t PIHrepetition;               // Number of times that all schedules will call its PIH. Do NOT use "0xFF" neither "0x0", because all schedules will run indefinitely.

void Startup_Serial(void) { Serial.begin(115200, SERIAL_8N1); }

void SetTimer2(void) {
    // Timer/Counter0 is configured to count CPU clock pulses. And when TCNT2 it overflows, variable "T2_MSW" is incremented.

    uint8_t sttreg = SREG;
    cli();
    TCCR2A = 0x00;
    TCCR2B = 0x00;
    TIMSK2 = 0x00;
    //--- Enable Timer/Counter2 module in Power Reduction Register PRR.
    PRR   &= (1 << PRTIM2);
    //--- Timer in Normal operation with TOP = 0xFF and TOV flag set on MAX: TCCR2A = 0x00
    TCCR2A &= ~( (1<<COM2A1)|(1<<COM2A0)|(1<<COM2B1)|(1<<COM2B0) | (1<<WGM21)|(1<<WGM20));
    //--- No prescaling. CPU clock will be counted: TCCR2B = 0x01;
    TCCR2B &= ~( (1<<FOC2A)|(1<<FOC2B)|(1<<WGM22) | (1<<CS22)|(1<<CS21) );
    TCCR2B |= (1 << CS20 );
    //--- Force Timer/Counter2 to stop counting:
    TCCR2B &= ~(1 << CS20 );
    //--- Reset TCNT2 (CPU clock counter).
    TCNT2  = 0x00;
    //--- Set TOIE2 flag (Timer/Counter2 Overflow Interrupt Enable) to enable ISR(TIMER2_OVF_vect).
    TIMSK2 &= ~( (1<<OCIE2B)|(1<<OCIE2A) );
    TIMSK2 |= (1 << TOIE2);
    //--- Force the Timer/Counter2 to disable its Overflow Interrupt ISR: TIMSK2 = 0x00;
    TIMSK2 &= ~(1 << TOIE2);
    //--- Set Asynchronous Status Register
    ASSR =  0x00;
    ASSR &= ~( (1 << EXCLK)|(1 << AS2) );

    SREG = sttreg;
}

void PIH_SafeGuardCheck(void) {
   // __asm__ __volatile__ ("nop\n\t");
   ++PIH_call;
}

void SetStartupError(char const *txt, int8_t r){
    Serial.print("ERROR: ");
    if (txt != 0x0) {
        Serial.print(txt);
        Serial.print(" returned ");
    }
    Serial.print(r);
    Serial.println(" .");
    Startup_Error = true;
}

void SafeGuardCheckError(uint8_t n, int8_t r){
    if (r < 0) {
        Serial.print("ERROR: MT_IncludeSchedule() [input: ");
        Serial.print(n);
        Serial.print("]  return = ");
        Serial.print(r);
        Startup_Error = true;
    }
}

bool SafeGuardCheckSchedules(void){
    //  All schedules will call the same PIH. They will be synchronized but will have a very small delay.

    MT_id_type SynchID = 0;
    uint8_t n = 0;
    int8_t r = 0;

    r = MT_IncludeSchedule( BaseInterval, &PIH_SafeGuardCheck, PIHrepetition, &SynchID);
    if (r < 0) {
        SafeGuardCheckError(n, r);
        return false;
    }

    for(++n; n < MultiTimersLimit; ++n ) {
        // r = MT_IncludeSchedule( BaseInterval, &PIH_SafeGuardCheck, PIHrepetition, 0x0, n, SynchID);
        r = MT_IncludeSchedule( BaseInterval, &PIH_SafeGuardCheck, PIHrepetition, 0x0, 10*n, SynchID);
        if (r < 0) {
            SafeGuardCheckError(n, r);
            return false;
        }
    }

    return true;
}

bool ConfigureSafeGuardCheck(void) {
    int8_t r;

    //--- Include (at least one) SCHEDULES.
    if (SafeGuardCheckSchedules() == false) { SetStartupError("SafeGuardCheckSchedules()", 0); return false;}

    //--- Enable Timer/Counter 1 to operate in CTC mode (Clear Timer on Compare Match).
    MT_SetCTCmode();

    //--- Configure Timer/Counter1 Prescaler
    r = MT_SelectPrescalerDivisor(); //  Configure the best value of Prescaler Divisor based on existing SCHEDULES.
    if (r < 0) { SetStartupError("MT_SelectPrescalerDivisor()", r); return false;}

    r = MT_SetClockSource(); //  Configure Timer/Counter1 clock frequency based on existing SCHEDULES.
    if (r < 0) { SetStartupError("MT_SetClockSource()", r); return false;}

    r = MT_SetSchedulesTicks(); //  Convert SCHEDULE's "period" parameter (defined in microseconds) to corresponding number of Timer/Counter1 Prescaler output ticks.
    if (r < 0) { SetStartupError("MT_SetSchedulesTicks()", r); return false;}

    r = MT_AlignSchedules(); //  Introduct offset delay in the first call of SCHEDULES' PIH that requires synchronization.
    if (r < 0) { SetStartupError("MT_AlignSchedules()", r); return false;}

    //--- Prepare Timer/Counter 1 to call the first PIH, loading the appropriate value int OCR1A.
    if (MT_PrepareOCR() == false) { SetStartupError("MT_PrepareOCR()", 0); return false;}

    SetTimer2();

    return true;
}

void StartTimers2n1(void) {
    uint8_t sttreg = SREG;
    cli();

    TCNT2 = 0x0;     // Reset Timer/Counter2 accumulator "TCNT1";
    TIMSK2 |= (1 << TOIE2);    // Set TOIE2 flag (Timer/Counter2 Overflow Interrupt Enable) to enable interrupt calls to ISR(TIMER2_OVF_vect).
    TCCR2B |= (1 << CS20 );    // Set no prescaling (Timer/Counter2 counts CPU clock cycles) to enable the count to start.

    TCNT1 = 0x0;  // Reset Timer/Counter1 accumulator "TCNT1";
    OCR1A = MT_schedule[0].periodticks; // << 2; // Write "MT_schedule[0].periodticks << 2" value into OCR1A.
    TIMSK1 = (1 << OCIE1A) | (1 << TOIE1);   // The flag "TOIE1" is enabled to detect an OVERFLOW on TCNT1.
    PRR   &= ~(1 << PRTIM1); // Enable Timer/Counter1 module in Power Reduction Register PRR.

    SREG = sttreg;
}

void StopTimers2n1(void) {
    uint8_t sttreg = SREG;
    cli();

    TIMSK2 &= ~(1 << TOIE2);    // Set TOIE2 flag (Timer/Counter2 Overflow Interrupt Enable) to enable interrupt calls to ISR(TIMER2_OVF_vect).
    TCCR2B &= ~(1 << CS20 );    // Set no prescaling (Timer/Counter2 counts CPU clock cycles) to enable the count to start.

    TIMSK1 &= ~( (1 << OCIE1A) | (1 << TOIE1) );   // The flag "TOIE1" is enabled to detect an OVERFLOW on TCNT1.
    PRR   |= (1 << PRTIM1); // Disable Timer/Counter1 module in Power Reduction Register PRR.

    SREG = sttreg;
}

void Print_SetupParameters(void) {
      Serial.print("Allowed SCHEDULES "); Serial.println(MT_scheduleslimit);
      Serial.print("SCHEDULES included "); Serial.println(MT_timersRunning);
      Serial.print("CPU freq "); Serial.println(MT_CpuFreq);
      Serial.print("Max. SCHEDULEs' period "); Serial.print(MT_maxInterval); Serial.println(" [microseconds]");
      Serial.print("Min. SCHEDULEs' period "); Serial.print(MT_minInterval); Serial.println(" [microseconds]");
      Serial.print("Timer 1 Prescaler divisor applied to CPU clock freq: "); Serial.println(MT_PrescalerDivisor);
      Serial.print("CPU clk freq DIVISOR of Timer 1 Prescaler "); Serial.println(MT_PrescalerDivisor);
      Serial.print("Timer1 Prescaler output period "); Serial.print(MT_Timer1Period);  Serial.println(" [microseconds]");
      Serial.print("Timer precision "); Serial.print(MT_PrescalerPrecision/10); Serial.print("% of the minimum period = ");
          Serial.print(MT_minInterval * MT_PrescalerPrecision/1000); Serial.println(" [microseconds]");
      Serial.print("Actual valid (or min. allowed) MT_uCCycleSafeGuard "); Serial.println(MT_uCCycleSafeGuard);
}

void Print_FaultParameters(void) {
      Serial.print("Times that a PIH should be called but was NOT ");  // ("Times that a PIH should be called but, because ISR(TIMER1_COMPA_vect) and other PIH may have long execution time, it could not: ");
      Serial.println(MT_LostPIHCall);
      Serial.print("Times that TCNT1 overflow (w/ no PIH call) ");    // ("Times that TCNT1 overflow occurred without call any PIH (because OCR1A value was lower than current TCNT1): ");
      Serial.println(MT_Tcnt1Overflow);
}

void setup(void){
    Startup_Serial();

    //--- Configure MultiTimer
    if (ConfigureSafeGuardCheck() == false) {
      Startup_Error = true;
      return;
    }
    PIHrepetition /= MT_timersRunning;
    Print_SetupParameters();

}

void loop(void){
    Serial.println("..running..");


    //--- Startup MultiTimer
    StartTimers2n1();

    //--- Wait until all schedules finish all PIH call.
    long d = ((long)BaseInterval * (PIHrepetition + 1)) / 1000 ;   // Time required to finish all SCHEDULEs (in miliseconds).
    delay(d);

    //--- Stop MultiTimer
    StopTimers2n1();


    //--- Show results
    Print_FaultParameters();
    Serial.print("ISR(TIMER1_COMPA_vect): \n\ttotal calls: ");
    Serial.println(T1_ISRcall);
    Serial.print("\tmean runtime (clock cycles): ");
    Serial.println(  ( ((float)T1_ISR_ClockPulses) - (PIH_call * (18)) )/T1_ISRcall  );  // The value "(6 + 11 + 9)" is the clock cycles required to run "PIH_call()" function itself .  Value 6 is the prologue, 11 is the function and 9 is the epilogue.
    //Serial.print("\tTimes that TCNT2 overflow during a single  TIMER1_COMPA_vect call: "); //("\tNumber of times that Timer/Counter2 TCNT2 overflow was detected while a single call to TIMER1_COMPA_vect was still running: ");
    //Serial.println(T2_MSW_Overflow);
}


/**/


